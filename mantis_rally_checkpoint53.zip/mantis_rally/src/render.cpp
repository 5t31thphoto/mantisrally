// Mantis Rally renderer. 160x120 palette indices; the palette is rebuilt every frame from the time of day,
// weather, biome and headlights (MantisPlanet's model: artist ramps lit by ambient + key, fog as palette work).
// Order: terrain (front to back, per column) -> panorama -> sky / clouds / night -> props (z-buffered) ->
// reflections (water, wet road) -> weather -> vehicle or cockpit -> glass -> instruments.
#include "render.h"
#include "sprites.h"
#include "terrain.h"
#include "journey.h"
#include "scene.h"
#include "field.h"
#include "vehicle.h"
#include "universe.h"
#include "mem.h"
#include "art.h"
#include "display.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#ifndef HOST
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#endif
#if !defined(HOST) && !defined(MR_NO_IRAM)
#include <esp_attr.h>
// inner loops in instruction RAM (no flash-cache stalls), as MantisPlanet does. noinline: a static function called
// once is otherwise inlined into its caller and follows the caller's section (ESP-IDF: "when a function is inlined, it
// will follow its caller's segment, and the attribute will not take effect") -- drawTerrain was landing in flash.
#define MR_HOT IRAM_ATTR __attribute__((noinline))
#define MR_FAST DRAM_ATTR
#else
#define MR_HOT
#define MR_FAST
#endif

namespace mantis {

ViewInfo g_view;

static constexpr int W = FB_W, H = FB_H;
static uint8_t fb[W * H];
static uint8_t* zb = nullptr;
// The palette as the panel takes it (RGB565, byte-swapped), four times: one per position in a 2x2 block. Every
// picture pixel is shown as a 2x2 block, so an ordered dither between the two nearest 565 colours there costs
// nothing and gives about two more bits of colour (smooth gradients, true dark tones: no bias from truncation).
static uint16_t pal565q[4 * 256];
// Fog the palette way (as MantisPlanet): every colour has fogged twins, the nearest palette colours (in its own ramp or
// the haze ramp) to it mixed toward the fog at four levels. Fog steps a pixel to its twin: no new colours, no dots.
static uint8_t s_fogLut[4][256];
static float s_fogRGB[3] = {128.f, 128.f, 128.f};
static int s_fogLvl = 0;
static const float FOG_MIX[4] = {0.22f, 0.45f, 0.68f, 0.88f};
static void buildFogLevel(const uint8_t* rgb, int lv) {
    float m = FOG_MIX[lv];
    for (int i = 0; i < 256; i++) {
        float tr = rgb[i * 3] + (s_fogRGB[0] - rgb[i * 3]) * m, tg = rgb[i * 3 + 1] + (s_fogRGB[1] - rgb[i * 3 + 1]) * m, tb = rgb[i * 3 + 2] + (s_fogRGB[2] - rgb[i * 3 + 2]) * m;
        int best = i; float bd = 1e30f;
        for (int pass = 0; pass < 2; pass++) {
            int base = pass == 0 ? (i & ~15) : P_HAZE;
            for (int k = 0; k < 16; k++) {
                int j = base + k;
                float dr = rgb[j * 3] - tr, dg = rgb[j * 3 + 1] - tg, db = rgb[j * 3 + 2] - tb;
                float d = dr * dr * 0.3f + dg * dg * 0.59f + db * db * 0.11f;
                if (d < bd) { bd = d; best = j; }
            }
        }
        s_fogLut[lv][i] = (uint8_t)best;
    }
}
#ifdef HOST
int renderFogTwinCount(int lv) { int n = 0; for (int i = 0; i < 256; i++) if (s_fogLut[lv][i] != i) n++; return n; }
#endif
// a fog amount (0..1) -> a twin: four clean bands with a thin seam on the surface grain (Planet's banding)
static inline uint8_t fogTwin(uint8_t c, float amt, float grain) {
    float f = amt * 4.f; int lv = (int)f; float fr = f - lv;
    if (fr > 0.86f || (fr > 0.62f && grain < 0.5f)) lv++;
    if (lv <= 0) return c;
    return s_fogLut[lv > 4 ? 3 : lv - 1][c];
}
static uint8_t palRGB[256 * 3];
static uint8_t s_refl[256];                // a palette entry's reflection (darker, same ramp)
static uint8_t s_bright[256];              // one step brighter in its ramp (light shafts)
static float s_light[256];                 // normal byte -> sunlight 0..1
static float s_lightSh[256];               // the same, out of the sun (the land shades it): sky light only
static float s_reliefK = 0.f;              // the ground's grain lit from the sun's side: strength, and the texel
static int s_rdu = 0, s_rdv = 0;           // offset toward the sun
static float s_fog[520];                   // fog by distance (m)
static uint8_t s_veh = 0;
static uint8_t s_bottom[W];                // rows at and below this are the cockpit's (not raycast)
static uint8_t s_bottomCock[W];
static uint8_t* s_cock = nullptr;          // decoded cockpit, 0 = glass
static uint8_t* s_wheelMask = nullptr;     // cockpit pixels that are the steering wheel
static uint8_t s_wheelBg = 0;              // the dash behind the wheel (drawn first, so nothing old shows through)
static float s_wheelK = 1.f;               // the wheel's ellipse (width / height, drawn in perspective)
static int s_wheelR = 0;                   // how far the wheel's pixels reach from its centre
static float s_wcx = 0.f, s_wcy = 0.f;     // the wheel's centre (to the half pixel: what it turns about)
// Wheels measured off the art by hand (zeros: found from the drawing at load, as before):
//   the rim: centre x, y, outer half-width, half-height;  the spokes: the row the side spokes run along, their
//   half-thickness;  the hub: centre x, y, radius.
// The Stingray's wheel is drawn from the sheet at one even scale (tools/sprites/make_cockpits.py, VETTE_WHEEL): these
// are the same measurements on the screen (pixel indices), so it turns about its own centre as the round wheel it is.
struct WheelFit { float cx, cy, rx, ry, spokeY, spokeH, hubX, hubY, hubR; };
static const WheelFit WHEEL_FIT[V_COUNT] = {{0}, {0}, {44.83f, 97.62f, 21.44f, 21.88f, 97.55f, 3.0f, 44.70f, 98.70f, 5.2f}, {0}};
static uint8_t s_glassLow[FB_W];           // per column: the lowest row of glass (behind the wheel above it: the world)
static float s_bob = 0.f;

static MR_FAST uint8_t BAYER[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
// As MantisPlanet: every dither keyed to world columns (x + pan, the heading in whole pixels), so the same pattern
// travels with the scenery as you turn instead of sitting on the screen. Pattern and densities are unchanged.
static int g_pan = 0;
static inline float dith(int x, int y) { return (BAYER[((y & 3) << 2) | ((x + g_pan) & 3)] + 0.5f) * (1.f / 16.f); }
// the aurora's pattern: anchored to the sky (view direction), twinkling (half ordered, half a hash that changes over time)
static inline float sdith(int su, int ry, float t, float twinkle) {
    float b = (BAYER[((ry & 3) << 2) | (su & 3)] + 0.5f) * (1.f / 16.f);
    uint32_t h = (uint32_t)su * 73856093u ^ (uint32_t)ry * 19349663u ^ (uint32_t)(t * 6.f) * 83492791u;
    h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
    return b * (1.f - twinkle) + (h & 1023u) * (1.f / 1024.f) * twinkle;
}
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static inline int clampi(int v, int a, int b) { return v < a ? a : (v > b ? b : v); }
static inline uint8_t zcode(float d) { float c = sqrtf(d > 0.f ? d : 0.f) * 11.f; return (uint8_t)((int)(c > 252.f ? 252.f : c) & ~1); }
static inline int band(float f, int x, int y) {              // Planet's pixel-art banding
    int i = (int)f; float fr = f - i;
    if (fr > 0.86f) return i + 1;
    if (fr > 0.62f && ((x ^ y) & 1)) return i + 1;
    return i;
}
static inline int ifloor(float v) { int i = (int)v; return v < (float)i ? i - 1 : i; }
static inline int iceil(float v) { int i = (int)v; return v > (float)i ? i + 1 : i; }
static inline float fastAtan2(float y, float x) {
    float ax = fabsf(x), ay = fabsf(y);
    float a = fminf(ax, ay) / (fmaxf(ax, ay) + 1e-9f);
    float s = a * a;
    float r = ((-0.0464964749f * s + 0.15931422f) * s - 0.327622764f) * s * a + a;
    if (ay > ax) r = 1.57079637f - r;
    if (x < 0) r = 3.14159274f - r;
    return y < 0 ? -r : r;
}

// ================================================================================== palette
struct C3 { float r, g, b; };
static inline C3 mix(C3 a, C3 b, float t) { return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t}; }
static inline C3 scale(C3 a, float s) { return {a.r * s, a.g * s, a.b * s}; }
static inline C3 add(C3 a, C3 b) { return {a.r + b.r, a.g + b.g, a.b + b.b}; }
static inline C3 mul(C3 a, C3 b) { return {a.r * b.r / 255.f, a.g * b.g / 255.f, a.b * b.b / 255.f}; }
static inline C3 c3(const uint8_t* p) { return {(float)p[0], (float)p[1], (float)p[2]}; }

struct Key { float t; C3 zen, hor, glow, cDark, cLit, sun, amb, key, fog; float elev, night, mist; };
#define NIGHT_KEY(T, E, M) {T, {6,5,20},{24,18,52},{40,24,70},{18,12,40},{95,55,150},{215,220,255},{70,75,120},{60,70,150},{26,22,55}, E, 1.0f, M}
static const Key KEYS[] = {             // MantisPlanet's day
    NIGHT_KEY(0.00f, -0.40f, 0.25f),
    {0.19f, {18,14,50},{75,42,105},{160,75,115},{40,28,75},{190,105,150},{255,200,160},{105,92,140},{190,105,125},{85,58,115}, -0.06f, 0.55f, 0.55f},
    {0.26f, {58,48,128},{238,118,92},{255,188,112},{105,58,118},{255,168,110},{255,240,190},{160,130,140},{255,150,80},{195,118,128}, 0.07f, 0.0f, 0.60f},
    {0.36f, {70,120,210},{188,208,235},{255,240,200},{138,150,190},{255,250,240},{255,255,230},{220,220,230},{255,230,180},{168,192,222}, 0.42f, 0.0f, 0.25f},
    {0.50f, {40,100,215},{168,208,245},{240,248,255},{150,165,200},{255,255,255},{255,255,240},{255,255,255},{255,245,220},{160,195,235}, 0.80f, 0.0f, 0.10f},
    {0.63f, {62,90,190},{218,190,172},{255,220,150},{150,128,170},{255,230,190},{255,245,200},{230,215,205},{255,210,140},{190,170,182}, 0.36f, 0.0f, 0.15f},
    {0.71f, {82,50,142},{255,118,70},{255,200,90},{120,50,110},{255,148,90},{255,240,170},{170,115,128},{255,128,50},{190,90,120}, 0.06f, 0.0f, 0.35f},
    {0.79f, {35,22,75},{178,50,100},{255,110,70},{60,30,80},{220,90,125},{255,180,120},{105,78,115},{200,70,80},{108,45,95}, -0.08f, 0.35f, 0.45f},
    NIGHT_KEY(0.89f, -0.35f, 0.30f),
    NIGHT_KEY(1.00f, -0.40f, 0.25f),
};
static constexpr int NKEYS = sizeof(KEYS) / sizeof(KEYS[0]);
static Key S;
static Key sampleKey(float tod) {
    int k = 0;
    while (k < NKEYS - 2 && tod >= KEYS[k + 1].t) k++;
    const Key &A = KEYS[k], &B = KEYS[k + 1];
    float t = clampf((tod - A.t) / (B.t - A.t), 0.f, 1.f); t = t * t * (3.f - 2.f * t);
    Key o; o.t = tod;
    o.zen = mix(A.zen, B.zen, t); o.hor = mix(A.hor, B.hor, t); o.glow = mix(A.glow, B.glow, t);
    o.cDark = mix(A.cDark, B.cDark, t); o.cLit = mix(A.cLit, B.cLit, t); o.sun = mix(A.sun, B.sun, t);
    o.amb = mix(A.amb, B.amb, t); o.key = mix(A.key, B.key, t); o.fog = mix(A.fog, B.fog, t);
    o.elev = A.elev + (B.elev - A.elev) * t; o.night = A.night + (B.night - A.night) * t; o.mist = A.mist + (B.mist - A.mist) * t;
    return o;
}
struct Ramp4 { C3 k[4]; };
static C3 rampAt(const Ramp4& r, float s) {
    s = clampf(s, 0.f, 1.f) * 3.f; int i = (int)s;
    return i >= 3 ? r.k[3] : mix(r.k[i], r.k[i + 1], s - i);
}
// an artist ramp from a biome's dark / lit pair: shadows lean cool, highlights warm (Planet's rule)
static Ramp4 artist(const uint8_t* d, const uint8_t* l) {
    C3 D = c3(d), Lc = c3(l);
    Ramp4 r;
    r.k[0] = mix(scale(D, 0.55f), C3{20, 30, 60}, 0.35f);
    r.k[1] = D;
    r.k[2] = mix(D, Lc, 0.6f);
    r.k[3] = mix(Lc, C3{255, 236, 170}, 0.18f);
    return r;
}
static Ramp4 blendR(const Ramp4& a, const Ramp4& b, float t) { Ramp4 r; for (int i = 0; i < 4; i++) r.k[i] = mix(a.k[i], b.k[i], t); return r; }

static float s_night = 0.f, s_lights = 0.f, s_sunK = 1.f;
static float s_artLit[3] = {1.f, 1.f, 1.f};      // the scene's light on the hero art (photo mode)
static float s_sunDx = 0.f, s_sunDy = 1.f, s_sunDz = 0.f;

static void buildPalette() {
    const Scene& sc = g_scene;
    const Biome& A = biome(sc.biomeA); const Biome& B = biome(sc.biomeB);
    float bl = sc.blend;
    S = sampleKey(sc.tod);
    // weather washes colour out (Planet's weatherKey)
    float grey = clampf(sc.cloud * 0.6f - 0.15f + sc.rain * 0.45f + sc.storm * 0.25f + sc.snow * 0.2f, 0.f, 0.9f);
    float dark = 1.f - 0.28f * sc.rain - 0.25f * sc.storm;
    auto desat = [](C3 c, float k, float d) -> C3 { float l = c.r * 0.3f + c.g * 0.55f + c.b * 0.15f; return scale(mix(c, C3{l * 0.92f, l * 0.96f, l * 1.05f}, k), d); };
    S.zen = desat(S.zen, grey, dark); S.hor = desat(S.hor, grey * 0.8f, dark); S.glow = desat(S.glow, grey * 0.9f, dark);
    S.cDark = desat(S.cDark, grey, dark * 0.85f); S.cLit = desat(S.cLit, grey * 0.8f, dark); S.fog = desat(S.fog, grey * 0.7f, dark);
    S.amb = scale(S.amb, 1.f - 0.25f * grey); 
    {   // looking toward a low sun the haze glows, lit from behind: a warm veil toward the sun, none away from it
        const float yaw = g_view.photo ? g_view.pYaw : g_view.yaw;
        const float face = cosf(sc.sunAz - yaw);
        const float low = clampf(1.f - sc.sunElev / 0.45f, 0.f, 1.f) * clampf((sc.sunElev + 0.08f) * 12.f, 0.f, 1.f);
        if (face > 0.f && low > 0.f) S.fog = mix(S.fog, S.glow, 0.3f * face * face * low * (1.f - grey));
    }
    s_sunK = (1.f - 0.75f * grey) * clampf((S.elev + 0.05f) * 4.f, 0.f, 1.f);
    s_night = S.night;
    s_lights = g_view.photo ? 0.f : sc.lights;      // photos: the camera is not the car, so no beams from it
    // the key light: the sun by day; the headlights by night
    C3 key = scale(S.key, 1.f - 0.75f * grey);
    C3 skyKey = key;                                 // daylight / moonlight only (the art in a photo isn't in its own beams)
    C3 HEAD = {255, 238, 205};
    key = mix(key, HEAD, clampf(s_lights * (0.25f + S.night * 0.9f), 0.f, 1.f));
    C3 amb = S.amb;
    if (S.night > 0.3f) amb = add(amb, scale(C3{14, 18, 34}, sc.moon * S.night));
    C3 P[256];
    memset(P, 0, sizeof(P));
    auto litR = [&](const Ramp4& r, float s) -> C3 {
        C3 b = rampAt(r, s);
        return add(scale(mul(b, amb), 0.55f + 0.45f * s), scale(mul(b, key), s * s * 0.55f));
    };
    Ramp4 grass = blendR(artist(A.grassD, A.grassL), artist(B.grassD, B.grassL), bl);
    Ramp4 soil = blendR(artist(A.soilD, A.soilL), artist(B.soilD, B.soilL), bl);
    Ramp4 rock = blendR(artist(A.rockD, A.rockL), artist(B.rockD, B.rockL), bl);
    Ramp4 leaf = blendR(artist(A.leafD, A.leafL), artist(B.leafD, B.leafL), bl);
    C3 acc = mix(c3(A.accent), c3(B.accent), bl);
    C3 wat = mix(c3(A.waterC), c3(B.waterC), bl);
    C3 mtn = mix(c3(A.mtn), c3(B.mtn), bl);
    uint8_t surf = bl < 0.5f ? A.surface : B.surface;
    if (sc.wet > 0.2f) { for (int i = 0; i < 4; i++) { soil.k[i] = scale(soil.k[i], 1.f - 0.25f * sc.wet); grass.k[i] = mix(grass.k[i], C3{16, 50, 52}, 0.2f * sc.wet); } }
    Ramp4 asph;
    if (surf == SURF_SNOW) asph = {{{120, 130, 160}, {170, 180, 205}, {215, 222, 238}, {245, 248, 255}}};
    else asph = {{{22, 22, 34}, {44, 44, 56}, {78, 76, 84}, {128, 124, 122}}};
    if (sc.wet > 0.2f) for (int i = 0; i < 4; i++) asph.k[i] = scale(asph.k[i], 1.f - 0.3f * sc.wet);
    static const Ramp4 SNOWR = {{{120, 140, 190}, {180, 196, 228}, {226, 234, 248}, {255, 255, 255}}};
    static const Ramp4 BARKR = {{{40, 24, 32}, {88, 52, 36}, {150, 92, 52}, {210, 150, 90}}};
    Ramp4 leaf2 = {{scale(acc, 0.3f), scale(acc, 0.6f), acc, mix(acc, C3{255, 250, 220}, 0.3f)}};
    Ramp4 haze = {{scale(S.fog, 0.55f), scale(S.fog, 0.8f), S.fog, mix(S.fog, S.hor, 0.6f)}};
    Ramp4 mt = {{mix(scale(mtn, 0.5f), C3{30, 30, 60}, 0.3f), mtn, mix(mtn, C3{200, 190, 180}, 0.4f), C3{235, 238, 250}}};
    for (int i = 0; i < 16; i++) {
        float t = i / 15.f;
        P[P_SKY + i] = i < 10 ? mix(S.zen, S.hor, powf(i / 9.f, 1.15f)) : mix(S.hor, S.glow, (i - 9) / 6.f);
        C3 c = mix(S.cDark, S.cLit, t);
        P[P_CLOUD + i] = mix(c, S.hor, 0.22f * sinf(t * 3.14159f));
        // mountains: 0..7 far (hazed), 8..15 near
        float s = (i & 7) / 7.f;
        C3 m = rampAt(mt, s * 0.92f + (s > 0.85f ? 0.08f : 0.f));
        C3 ml = add(scale(mul(m, amb), 0.55f + 0.5f * s), scale(mul(m, key), s * s * 0.45f));
        P[P_MTN + i] = mix(ml, S.fog, i < 8 ? 0.5f : 0.25f);
        P[P_HAZE + i] = rampAt(haze, t);
        P[P_GRASS + i] = litR(grass, t);
        P[P_SOIL + i] = litR(soil, t);
        P[P_ROCK + i] = litR(rock, t);
        P[P_ROAD + i] = litR(asph, t);
        P[P_LEAF + i] = litR(leaf, t);
    }
    for (int i = 0; i < 8; i++) {
        float t = i / 7.f;
        P[P_SUN + i] = i == 7 ? mix(S.sun, C3{255, 255, 255}, 0.4f) : mix(S.glow, S.sun, t);
        P[P_LEAF2 + i] = litR(leaf2, t);
        P[P_SNOW + i] = litR(SNOWR, t);
        P[P_BARK + i] = litR(BARKR, t);
        P[P_WATER + i] = add(scale(mul(wat, amb), 0.5f + 0.5f * t), scale(mul(wat, key), t * 0.3f));
    }
    // special: rainbow by day, aurora by night
    static const C3 BOW[8] = {{150, 90, 230}, {80, 120, 255}, {70, 200, 235}, {90, 225, 110}, {250, 235, 90}, {255, 160, 60}, {240, 70, 60}, {255, 255, 255}};
    static const C3 AUR[8] = {{8, 30, 44}, {20, 90, 80}, {40, 170, 110}, {60, 225, 140}, {120, 245, 170}, {120, 140, 230}, {170, 100, 240}, {220, 160, 255}};
    for (int i = 0; i < 8; i++) P[P_SPECIAL + i] = S.night > 0.5f ? AUR[i] : mix(BOW[i], P[P_SKY + 9], 0.25f);
    // flowers: lit, saturated
    static const C3 FL[8] = {{250, 250, 240}, {255, 220, 60}, {200, 120, 230}, {255, 130, 170}, {230, 60, 60}, {110, 150, 255}, {255, 160, 60}, {245, 245, 255}};
    for (int i = 0; i < 8; i++) P[P_FLOWER + i] = mix(add(scale(mul(FL[i], amb), 0.8f), scale(mul(FL[i], key), 0.45f)), mul(FL[i], amb), 0.3f);
    if (A.accent[0] > 0) P[P_FLOWER + 2] = mix(P[P_FLOWER + 2], litR(leaf2, 0.8f), 0.6f);
    for (int k = 0; k < 3; k++) { float a = (&amb.r)[k], kk = (&skyKey.r)[k] * (1.f - S.night); s_artLit[k] = clampf((a * 0.62f + kk * 0.48f) / 255.f, 0.08f, 1.15f); }
    // the vehicle and its cockpit, lit by the scene
    const art::VehArt& va = art::VEH_ART[s_veh];
    const art::CockArt& ca = art::COCK_ART[s_veh];
    for (int i = 0; i < 15; i++) {
        C3 v = {(float)va.pal[i * 3], (float)va.pal[i * 3 + 1], (float)va.pal[i * 3 + 2]};
        C3 lit = add(scale(mul(v, amb), 0.75f), scale(mul(v, key), 0.42f));
        P[P_VEH + 1 + i] = lit;
        C3 k = {(float)ca.pal[i * 3], (float)ca.pal[i * 3 + 1], (float)ca.pal[i * 3 + 2]};
        float satk = fmaxf(k.r, fmaxf(k.g, k.b)) - fminf(k.r, fminf(k.g, k.b));
        C3 kl = add(scale(mul(k, amb), 0.62f), scale(mul(k, S.key), 0.3f * (1.f - S.night)));
        if (satk > 60.f && k.g > k.r) kl = mix(kl, k, 0.6f + 0.4f * S.night);      // instrument glow
        P[P_COCK + 1 + i] = kl;
    }
    // emissive
    P[P_HUD_W] = {242, 246, 250}; P[P_HUD_A] = {255, 190, 50}; P[P_HUD_R] = {255, 70, 60}; P[P_HUD_G] = {120, 255, 120};
    P[P_HUD_K] = {12, 14, 20}; P[P_FIREFLY] = {225, 255, 130}; P[P_WINDOW] = mix(C3{60, 70, 80}, C3{255, 200, 110}, S.night);
    P[P_BEAM] = mix(S.fog, C3{255, 240, 200}, 0.35f);
    // paint is retro-reflective: it shines in the headlights
    for (int i = 0; i < 4; i++) {
        float t = i / 3.f;
        P[P_LINE_W + i] = add(scale(mul(C3{235, 235, 228}, amb), 0.5f + 0.4f * t), scale(mul(C3{235, 235, 228}, key), t * 0.6f));
        P[P_LINE_Y + i] = add(scale(mul(C3{240, 196, 40}, amb), 0.5f + 0.4f * t), scale(mul(C3{240, 196, 40}, key), t * 0.6f));
    }
    P[P_SIGN_G] = add(scale(mul(C3{20, 110, 60}, amb), 0.8f), scale(mul(C3{20, 110, 60}, key), 0.5f));
    P[P_SIGN_W] = add(scale(mul(C3{240, 240, 240}, amb), 0.7f), scale(mul(C3{240, 240, 240}, key), 0.6f + s_lights * S.night * 0.4f));
    P[P_TAIL_D] = {120, 16, 24}; P[P_TAIL] = {255, 40, 40}; P[P_AMBER] = {255, 170, 40}; P[P_BLACK] = {10, 10, 14};
    P[P_BOLT] = {235, 235, 255}; P[P_MUD] = mul(C3{70, 48, 30}, add(scale(amb, 0.7f), scale(key, 0.3f)));
    // Lit colours can pass 255 (sun plus sky); clipped channel by channel they lose their hue and the top of each ramp
    // goes flat. A shoulder instead: above 235 the brightest channel rolls off toward 255 and the others scale with it.
    {   auto shoulder = [](C3& c) {
            float m = fmaxf(c.r, fmaxf(c.g, c.b));
            if (m > 235.f) { float e = m - 235.f, k = (235.f + 20.f * e / (e + 20.f)) / m; c.r *= k; c.g *= k; c.b *= k; }
        };
        for (int i = P_MTN; i < P_MTN + 16; i++) shoulder(P[i]);
        for (int i = P_GRASS; i < P_WATER + 8; i++) shoulder(P[i]);
        for (int i = P_VEH + 1; i < P_FLOWER + 8; i++) shoulder(P[i]);          // vehicle, cockpit, flowers
        for (int i = P_LINE_W; i <= P_SIGN_W; i++) shoulder(P[i]);             // paint and signs
        shoulder(P[P_MUD]);
    }
    // lightning lifts everything toward a cold white
    if (sc.flash > 0.01f) for (int i = 0; i < 232; i++) P[i] = mix(P[i], C3{225, 230, 255}, sc.flash * (i < P_GRASS ? 0.6f : 0.3f));
    static const float DQ[4] = {0.125f, 0.625f, 0.875f, 0.375f};   // 2x2 ordered offsets: (0,0) (1,0) (0,1) (1,1)
    for (int i = 0; i < 256; i++) {
        const float cr = clampf(P[i].r, 0.f, 255.f), cg = clampf(P[i].g, 0.f, 255.f), cb = clampf(P[i].b, 0.f, 255.f);
        palRGB[i * 3] = (uint8_t)(cr + 0.5f); palRGB[i * 3 + 1] = (uint8_t)(cg + 0.5f); palRGB[i * 3 + 2] = (uint8_t)(cb + 0.5f);
        const float r5 = cr * (31.f / 255.f), g6 = cg * (63.f / 255.f), b5 = cb * (31.f / 255.f);
        for (int q = 0; q < 4; q++) {
            int r = (int)(r5 + DQ[q]), g = (int)(g6 + DQ[q]), b = (int)(b5 + DQ[q]);
            if (r > 31) r = 31;
            if (g > 63) g = 63;
            if (b > 31) b = 31;
            const uint16_t v = (uint16_t)((r << 11) | (g << 5) | b);
            pal565q[q * 256 + i] = (uint16_t)((v >> 8) | (v << 8));
        }
    }
    s_fogRGB[0] = clampf(S.fog.r, 0.f, 255.f); s_fogRGB[1] = clampf(S.fog.g, 0.f, 255.f); s_fogRGB[2] = clampf(S.fog.b, 0.f, 255.f);
    static bool fogMade = false;
    if (!fogMade) { for (int l = 0; l < 4; l++) buildFogLevel(palRGB, l); fogMade = true; }
    else {                                                  // the palette drifts slowly: one level every 8 frames
        static uint8_t tick = 0;
        if (!(tick++ & 7)) { buildFogLevel(palRGB, s_fogLvl); s_fogLvl = (s_fogLvl + 1) & 3; }
    }
}

// ramp tables for reflections and light shafts (static: built once)
static void buildLUTs() {
    for (int i = 0; i < 256; i++) { s_refl[i] = (uint8_t)i; s_bright[i] = (uint8_t)i; }
    auto r16 = [](int base) { for (int k = 0; k < 16; k++) { s_refl[base + k] = (uint8_t)(base + (k > 2 ? k - 2 : 0)); s_bright[base + k] = (uint8_t)(base + (k < 14 ? k + 2 : 15)); } };
    auto r8 = [](int base) { for (int k = 0; k < 8; k++) { s_refl[base + k] = (uint8_t)(base + (k > 1 ? k - 1 : 0)); s_bright[base + k] = (uint8_t)(base + (k < 7 ? k + 1 : 7)); } };
    r16(P_SKY); r16(P_CLOUD); r16(P_MTN); r16(P_HAZE); r16(P_GRASS); r16(P_SOIL); r16(P_ROCK); r16(P_ROAD); r16(P_LEAF);
    r8(P_SUN); r8(P_LEAF2); r8(P_SNOW); r8(P_BARK); r8(P_WATER);
    for (int k = 0; k < 8; k++) s_refl[P_SUN + k] = (uint8_t)(P_SUN + k);     // the sun glitters, undimmed
}

// ================================================================================== camera
static float cx, cy, cz, cyaw, F, fx, fz, rx, rz, hor0, rollT;
static float horX[W], kxC[W], dxC[W], dzC[W], azC[W], beamC[W], sideC[W];
static uint8_t ymin[W];
static float s_camYaw = 0.f, s_camY = 0.f;
static bool s_camInit = false;
static uint8_t s_camView = 255; static float s_camX = 0.f, s_camZ = 0.f;   // last frame's view and car (to re-seat)
static float s_t = 0.f;

bool renderProject(float wx, float wy, float wz, float& sx, float& sy, float& depth) {
    float dx = wx - cx, dz = wz - cz;
    depth = dx * fx + dz * fz;
    if (depth < 0.3f) return false;
    float lat = dx * rx + dz * rz;
    sx = W * 0.5f + lat / depth * F;
    sy = hor0 + (sx - W * 0.5f) * rollT - (wy - cy) * F / depth;
    return true;
}

static void setupCamera() {
    const ViewInfo& v = g_view;
    const VehicleSpec& V = vehicleSpec(v.vehicle);
    float pitch, roll;
    // the chase camera starts behind the car whenever you come into that view or the car is put somewhere new (a
    // reset): its smoothing is for following the car, not for flying in from wherever it was last time
    if (v.view != s_camView || (v.x - s_camX) * (v.x - s_camX) + (v.z - s_camZ) * (v.z - s_camZ) > 30.f * 30.f) s_camInit = false;
    s_camView = v.view; s_camX = v.x; s_camZ = v.z;
    if (v.photo) {
        cx = v.pX; cy = v.pY; cz = v.pZ; cyaw = v.pYaw;
        F = 96.f; pitch = v.pPitch; roll = 0.f;
        hor0 = H * 0.5f + tanf(pitch) * F;
    } else if (v.view == VIEW_CHASE) {
        float back = v.vehicle == V_BIKE ? 3.9f : 6.6f;
        if (!s_camInit) { s_camYaw = v.yaw; s_camY = v.groundY; s_camInit = true; }
        s_camYaw += wrapPi(v.yaw - s_camYaw) * clampf(g_scene.dt * 3.2f, 0.f, 1.f);
        s_camY += (v.groundY - s_camY) * clampf(g_scene.dt * 5.f, 0.f, 1.f);
        cyaw = s_camYaw;
        cx = v.x - cosf(cyaw) * back; cz = v.z - sinf(cyaw) * back;
        float gh = terrainHeight(cx, cz);
        cy = fmaxf(s_camY + 1.65f, gh + 1.0f);
        F = 120.f; pitch = -0.0873f; roll = 0.f;
        hor0 = H * 0.5f + tanf(pitch) * F;
    } else {
        cyaw = v.yaw;
        float c = cosf(v.yaw), s = sinf(v.yaw);
        cx = v.x + c * V.eyeBack; cz = v.z + s * V.eyeBack;
        cy = v.groundY + V.eyeHeight + v.bounce * 0.6f;
        // speed perspective: the view opens up to 13% wider between 45 and 120 mph (smoothed): speed you can feel
        {   static float s_fovK = 1.f;
            const float tgt = 1.f - 0.13f * clampf((v.speedMph - 45.f) * (1.f / 75.f), 0.f, 1.f);
            s_fovK += (tgt - s_fovK) * clampf(g_scene.dt * 2.5f, 0.f, 1.f);
            F = (v.view == VIEW_COCKPIT ? 92.f : 96.f) * s_fovK;
        }
        pitch = v.pitch * 0.75f - 0.05f;
        roll = V.bike ? v.lean * 0.45f + v.roll * 0.3f : v.roll * 0.6f;
        hor0 = H * 0.47f + tanf(pitch) * F;
    }
    fx = cosf(cyaw); fz = sinf(cyaw); rx = -fz; rz = fx;
    g_pan = (int)lroundf(cyaw * F);
    rollT = -tanf(roll);                 // camera rolled right (right side down): the horizon's right end rises
    for (int x = 0; x < W; x++) {
        float kx = (x + 0.5f - W * 0.5f) / F;
        kxC[x] = kx; dxC[x] = fx + rx * kx; dzC[x] = fz + rz * kx;
        horX[x] = hor0 + (x + 0.5f - W * 0.5f) * rollT;
        azC[x] = cyaw + atanf(kx);
        float b = 1.f - (kx * kx) / 0.17f;
        beamC[x] = b > 0.f ? b : 0.f;
        sideC[x] = sinf(wrapPi(g_scene.sunAz - azC[x]));
    }
}

// ================================================================================== terrain
struct Smp { float h, a, al, lt; uint8_t mat, surf, half, extra; };
static uint8_t* s_tex = nullptr;            // 64x64 value noise, 0..255
static inline int tex(int u, int v) { return s_tex[((v & 63) << 6) | (u & 63)]; }
// The dither for the ground, water and road: the same world-position texture lookup the ground's own detail uses
// (so it sits on the surface and moves with it), with the texture's values equalized so every effect keeps the
// same coverage the old screen pattern gave it.
static uint8_t s_texRank[256];
static bool s_rankMade = false;
static void makeTexRank() {
    int hist[256] = {0};
    for (int i = 0; i < 64 * 64; i++) hist[s_tex[i]]++;
    int acc = 0;
    for (int v = 0; v < 256; v++) { s_texRank[v] = (uint8_t)((acc + hist[v] / 2) * 255 / (64 * 64)); acc += hist[v]; }
    s_rankMade = true;
}
// The same fine grain as the old screen pattern (uniform, pixel-sized), but each grain belongs to a spot on the
// surface: a fixed random value per tiny patch of world, sized 1-2 pixels at its distance. Coverage is unchanged.
static inline float surfDith(float wx, float wz, float z) {
    int zi = (int)z;
    int L = zi > 1 ? 31 - __builtin_clz((unsigned)zi) : 0;          // halvings of the distance until 1 (as the old loop)
    if (L > 12) L = 12;
    uint32_t pb = (uint32_t)(127 - L) << 23; float inv2; memcpy(&inv2, &pb, 4);   // 2^-L exactly
    float s = 48.f * inv2;                                           // = 48 / 2^L, bit for bit
    uint32_t ix = (uint32_t)(int32_t)ifloor(wx * s), iz = (uint32_t)(int32_t)ifloor(wz * s);
    uint32_t h = ix * 0x8DA6B343u ^ iz * 0xD8163841u ^ (uint32_t)L * 0xCB1AB31Fu;
    h ^= h >> 15; h *= 0x2C1B3C6Du; h ^= h >> 12; h *= 0x297A2D39u; h ^= h >> 15;
    return ((h >> 8) & 0xFFFF) * (1.f / 65536.f);
}
static uint8_t* s_gpat = nullptr;
static bool s_mistOn = false;                     // the mist band will read the grain under it this frame                 // per pixel: the surface's dither value (for the reflection pass)
// A ray sample, in two halves: its height (every sample needs it), and the rest (only for samples that draw: about a
// third of them are behind nearer land). Same cells, same weights, same arithmetic as the old sampleAt / sampleLite:
// near samples (lite = false) blend road distance and light; distant ones (lite = true) take them from the nearest cell.
struct Probe { const Cell *a, *b, *c, *d; const Grid* g; float tx, tz, h; bool lite; };
// a cell's light: the sun's, or the sky's only where the land shades it from the sun
// Cloud shadows: a soft blob map (32 x 32, 70 m a cell, wrapping both ways: no seams) drifting with the wind. Only on
// part-cloudy sunny days, and gently: at most ~16% off the light.
static uint8_t s_cloudMap[32 * 32];
static float s_cloudOx = 0.f, s_cloudOz = 0.f, s_cloudThr = 999.f, s_cloudAmt = 0.f;
static inline __attribute__((always_inline)) float cloudK(float x, float z) {
    const float u = (x + s_cloudOx) * (1.f / 70.f), v = (z + s_cloudOz) * (1.f / 70.f);
    const int iu = ifloor(u), iv = ifloor(v);
    float tu = u - iu, tv = v - iv;
    tu = tu * tu * (3.f - 2.f * tu); tv = tv * tv * (3.f - 2.f * tv);
    const int x0 = iu & 31, x1 = (iu + 1) & 31, z0 = (iv & 31) << 5, z1 = ((iv + 1) & 31) << 5;
    const float a = s_cloudMap[z0 | x0], b = s_cloudMap[z0 | x1], c = s_cloudMap[z1 | x0], d = s_cloudMap[z1 | x1];
    const float ab = a + (b - a) * tu, cd = c + (d - c) * tu;
    const float sh = clampf((ab + (cd - ab) * tv - s_cloudThr) * (1.f / 40.f), 0.f, 1.f);
    return 1.f - s_cloudAmt * sh;
}
static inline __attribute__((always_inline)) float cellLight(const Grid& g, const Cell& k) {
    const int i = (int)(&k - g.c);
    return (g.sh && ((g.sh[i >> 3] >> (i & 7)) & 1) ? s_lightSh : s_light)[k.nrm];
}
// check: test the window's bounds (false: the caller knows this spot is well inside them)
static inline __attribute__((always_inline)) bool probeAt(const Grid& g, int wrap, float wx, float wz, bool lite, Probe& p, bool check = true) {
    float gx = wx * g.inv, gz = wz * g.inv;
    int ix, iz;
    if (lite) { ix = (int)(gx + 4096.f) - 4096; iz = (int)(gz + 4096.f) - 4096; }
    else { ix = ifloor(gx); iz = ifloor(gz); }
    if (check && (ix < g.ox + 1 || iz < g.oz + 1 || ix + 2 >= g.ox + g.N || iz + 2 >= g.oz + g.N)) return false;
    p.tx = gx - ix; p.tz = gz - iz; p.lite = lite; p.g = &g;
    const int N = g.N;
    int x0 = ix - g.ox + (wrap & 0xFFFF); if (x0 >= N) x0 -= N;        // = ix mod N (the window's origin, wrapped once a frame)
    int z0 = iz - g.oz + (wrap >> 16); if (z0 >= N) z0 -= N;
    int x1 = x0 + 1 == N ? 0 : x0 + 1, z1 = z0 + 1 == N ? 0 : z0 + 1;
    p.a = &g.c[z0 * N + x0]; p.b = &g.c[z0 * N + x1]; p.c = &g.c[z1 * N + x0]; p.d = &g.c[z1 * N + x1];
    float h0 = p.a->h + (p.b->h - p.a->h) * p.tx, h1 = p.c->h + (p.d->h - p.c->h) * p.tx;
    p.h = (h0 + (h1 - h0) * p.tz) * 0.1f;
    return true;
}
static inline __attribute__((always_inline)) const Cell& probeNearest(const Probe& p) { return p.tx < 0.5f ? (p.tz < 0.5f ? *p.a : *p.c) : (p.tz < 0.5f ? *p.b : *p.d); }
static inline __attribute__((always_inline)) void probeAttr(const Probe& p, Smp& s) {
    const Cell &a = *p.a, &b = *p.b, &c = *p.c, &d = *p.d;
    const Cell& n = probeNearest(p);
    const float tx = p.tx, tz = p.tz;
    s.h = p.h;
    if (p.lite) { s.a = n.across * 0.02f; s.lt = cellLight(*p.g, n); }
    else {
        float a0 = a.across + (b.across - a.across) * tx, a1 = c.across + (d.across - c.across) * tx;
        s.a = (a0 + (a1 - a0) * tz) * 0.02f;
        const float la = cellLight(*p.g, a), lb = cellLight(*p.g, b), lc = cellLight(*p.g, c), ld = cellLight(*p.g, d);
        float l0 = la + (lb - la) * tx, l1 = lc + (ld - lc) * tx;
        s.lt = l0 + (l1 - l0) * tz;
    }
    s.al = n.along * 0.05f;
    s.mat = n.mat & 15; s.surf = n.mat >> 4; s.extra = n.extra;
    s.half = (s.mat == MAT_ROAD || s.mat == MAT_SHOULDER) ? (n.extra & 0x7F) : 68;   // (bit 7: a tunnel)
}
static float s_lwNear = 0.f;                // z * 0.55 below this: the paint is at its minimum width (no divide needed)

static float s_flowers = 0.f, s_wet = 0.f, s_paved = 1.f;

// a field's pixel (Cell::extra bit 7): rows of corn, potato mounds or grain, the rows fading to their average colour
// once they're too fine to draw. Flash: only field pixels call it.
__attribute__((noinline)) static uint8_t cropPix(int x, int y, float wx, float wz, float s, float z, uint8_t extra) {
    const int kind = (extra >> 5) & 3;
    const float sp = kind == 2 ? 0.35f : 0.9f;                       // metres between rows
    float f = ((extra & 0x10) ? wx : wz) * (1.f / sp); f -= floorf(f);
    const float row = fabsf(f - 0.5f) * 2.f;                         // 0 on the row, 1 in the furrow
    const float vis = clampf((sp * F / (z + 0.1f) - 1.5f) * (1.f / 1.5f), 0.f, 1.f);   // rows at least ~3 px apart: drawn
    const uint32_t hp = hash32((uint32_t)(int)floorf(wx * 3.f) * 0x9E3779B1u ^ (uint32_t)(int)floorf(wz * 3.f) * 0x85EBCA77u);   // a third of a metre
    if (kind == 0) {                                                 // corn: tall bright rows, narrow dark furrows, gold tassels
        if (row > 1.f - 0.3f * vis) return (uint8_t)(P_SOIL + clampi(band(s - 3.f, x, y), 0, 15));
        if (vis > 0.3f && row < 0.5f && (hp & 15) == 0) return (uint8_t)(P_SOIL + clampi(band(s + 4.f, x, y), 0, 15));
        return (uint8_t)(P_GRASS + clampi(band(s + 0.6f - (1.f - vis) * 0.5f - row * 0.8f * vis, x, y), 0, 15));
    }
    if (kind == 1) {                                                 // potatoes: low, dark leafy mounds on wide brown ridges
        if (row > 1.f - 0.55f * vis) return (uint8_t)(P_SOIL + clampi(band(s - 0.5f - (row - 0.45f) * 2.f, x, y), 0, 15));
        return (uint8_t)(P_LEAF + clampi(band(s - 1.2f - (1.f - vis) * 0.5f - row * 1.6f * vis + ((hp & 3) == 0 ? 1.f : 0.f), x, y), 0, 15));
    }
    // grain: ripe gold, fine rows, stalk speckle
    if (vis > 0.2f && (hp & 31) == 0) return (uint8_t)(P_GRASS + clampi(band(s + 1.5f, x, y), 0, 15));   // a green stalk here and there
    return (uint8_t)(P_SOIL + clampi(band(s + 5.f - (row > 0.7f ? 2.6f * vis : 0.f) - ((hp & 7) == 0 ? 1.5f : 0.f), x, y), 0, 15));
}

// one ground pixel. Returns the palette index; sets *refl for water / wet surfaces.
static inline uint8_t groundPix(int x, int y, float wx, float wz, float a, float al, float half, float lt, float z, float hgt,
                                uint8_t mat, uint8_t surf, bool farSmp, uint8_t extra, bool& refl) {
    int scl = z < 12.f ? 5 : (z < 35.f ? 2 : 1);
    const int tu = (int)(wx * scl), tv = (int)(wz * scl);
    int n = tex(tu, tv);
    float nf = n * (1.f / 255.f);
    // more of the ramp for the light: shade lands where it always did (step 4), full sun about a step higher
    float s = lt * 13.5f - 0.48f + (nf - 0.5f) * 3.f;
    // grain facing the sun: lit. Never across the texture tile's edge: the tile repeats seamlessly in u but not in v, and
    // the difference across that seam drew a stripe every tile (12.8 m near, 32 m, 64 m far)
    if (s_reliefK > 0.f && !(((tv + s_rdv) ^ tv) & ~63) && !(((tu + s_rdu) ^ tu) & ~63))
        s += (float)(n - tex(tu + s_rdu, tv + s_rdv)) * s_reliefK;
    if (s_lights > 0.02f && z < 75.f) s += s_lights * beamC[x] * 10.f * (z + 3.f <= 11.f ? 1.f : fminf(1.f, 11.f / (z + 3.f))) * (0.35f + 0.65f * s_night);
    float aa = fabsf(a);
    uint8_t c;
    if (aa < half && mat != MAT_WATER) {
        if (surf == SURF_TARMAC) {
            const float lz = z * 0.55f;
            const float lw = lz < s_lwNear ? 0.10f : fmaxf(0.10f, lz / F);   // paint never thinner than ~half a pixel
            int lv = clampi(band(s * 0.9f + 1.f, x, y), 0, 15);
            c = (uint8_t)(P_ROAD + lv);
            if (z < 25.f && tex((int)(wx * 9.f), (int)(wz * 9.f)) > 228) c = (uint8_t)(P_ROAD + clampi(lv + 2, 0, 15));
            float e = fabsf(aa - (half - 0.32f));
            float m = al;
            float sl = s * 0.25f + 0.2f;
            if (e < lw) c = (uint8_t)(P_LINE_W + clampi((int)sl, 0, 3));
            else if (aa < lw + 0.05f && m < 4.6f) c = (uint8_t)(P_LINE_Y + clampi((int)sl, 0, 3));
            if (s_wet > 0.25f) refl = true;
        } else if (surf == SURF_SNOW) {
            float rut = fabsf(aa - half * 0.48f);
            int lv = (int)(s * 0.5f + 1.5f - (rut < 0.45f ? 2.f : 0.f) + dith(x, y));
            c = (uint8_t)(P_SNOW + clampi(lv, 0, 7));
        } else {
            float rut = fabsf(aa - half * 0.48f);
            float sh = s + 1.0f;
            if (rut < 0.5f) sh -= surf == SURF_MUD ? 3.f : 1.8f;
            if (aa < 0.45f) sh += 0.8f;
            if (surf == SURF_GRAVEL && z < 22.f && tex((int)(wx * 11.f), (int)(wz * 11.f)) > 205) sh += 3.f;
            if (surf == SURF_SAND) sh += 1.5f + sinf(wx * 1.3f + wz * 0.7f) * 0.8f;
            if (surf == SURF_DIRT) sh -= 0.6f;
            c = (uint8_t)(P_SOIL + clampi(band(sh, x, y), 0, 15));
            if (surf == SURF_MUD) {
                c = (uint8_t)(P_SOIL + clampi(band(sh * 0.7f - 1.f, x, y), 0, 15));
                if (rut < 0.55f && tex((int)(wx * 1.5f), (int)(wz * 1.5f)) > 120) refl = true;
            } else if (s_wet > 0.5f && rut < 0.4f && tex((int)(wx * 1.2f), (int)(wz * 1.2f)) > 170) refl = true;
        }
    } else if (aa < half + 1.3f && mat != MAT_WATER) {
        int lv = band(s * 0.9f + (s_paved > 0.5f ? 1.f : 0.f), x, y);
        c = (uint8_t)(P_SOIL + clampi(lv, 0, 15));
        if (nf > 0.62f && aa > half + 0.7f) c = (uint8_t)(P_GRASS + clampi(lv, 0, 15));
    } else {
        switch (mat) {
            case MAT_WATER: {
                int r = (int)((nf - 0.5f) * 4.f + 3.f + (z < 20.f ? 1.f : 0.f));
                refl = true;
                return (uint8_t)(P_WATER + clampi(r, 0, 7));
            }
            case MAT_ROCK: {
                float strata = sinf(hgt * 2.4f + nf * 2.f) * 1.3f;
                c = (uint8_t)(P_ROCK + clampi(band(s + strata + 0.5f, x, y), 0, 15));
                break;
            }
            case MAT_SNOW: c = (uint8_t)(P_SNOW + clampi((int)(s * 0.55f + 1.f + dith(x, y)), 0, 7)); break;
            case MAT_SAND: c = (uint8_t)(P_SOIL + clampi(band(s + 2.f + sinf(wx * 0.9f + wz * 0.5f) * 0.9f, x, y), 0, 15)); break;
            case MAT_SOIL: c = (extra & 0x80) ? cropPix(x, y, wx, wz, s, z, extra) : (uint8_t)(P_SOIL + clampi(band(s, x, y), 0, 15)); break;
            case MAT_MUD:
                c = (uint8_t)(P_SOIL + clampi(band(s * 0.6f - 1.f, x, y), 0, 15));
                if (nf > 0.6f) { refl = true; }
                break;
            case MAT_LOT: c = (uint8_t)(P_SOIL + clampi(band(s + 1.f, x, y), 0, 15)); break;
            default: {
                if (farSmp && extra > 0 && extra < 0x80 && mat < MAT_WATER) {                      // distant forest canopy
                    int lv = (int)(s * 0.8f - 1.f + nf * 3.f);
                    return (uint8_t)(P_LEAF + clampi(lv, 0, 15));
                }
                float blades = z < 14.f ? (tex((int)(wx * 9.f), (int)(wz * 3.f)) - 128) * (1.f / 60.f) : 0.f;
                c = (uint8_t)(P_GRASS + clampi(band(s + blades, x, y), 0, 15));
                if (s_flowers > 0.05f && z < 40.f) {
                    int fl = tex((int)(wx * 3.f) * 7 + 13, (int)(wz * 3.f) * 5 + 29);
                    if (fl > 250 - (int)(s_flowers * 30.f)) c = (uint8_t)(P_FLOWER + ((int)(wx * 3.f + wz * 7.f) & 7));
                }
            }
        }
    }
    return c;
}

// How far a column's ray (direction ddx, ddz from the camera) certainly stays inside the near cache's usable cells.
// Once a column: flash (not inlined into IRAM).
__attribute__((noinline)) static float nearSafeZ(const Grid& gN, float ddx, float ddz) {
    const float ax = cx * gN.inv, bx = ddx * gN.inv, az = cz * gN.inv, bz = ddz * gN.inv;
    const float lox = gN.ox + 1.25f, hix = gN.ox + gN.N - 3.25f, loz = gN.oz + 1.25f, hiz = gN.oz + gN.N - 3.25f;
    if (!(ax > lox && ax < hix && az > loz && az < hiz)) return 0.f;
    float sx = bx > 0.f ? (hix - ax) / bx : (bx < 0.f ? (lox - ax) / bx : 1e30f);
    float sz = bz > 0.f ? (hiz - az) / bz : (bz < 0.f ? (loz - az) / bz : 1e30f);
    return sx < sz ? sx : sz;
}
// The terrain, a column at a time: columns are independent (each writes only its own pixels and ymin), so both
// cores draw them, taking blocks of columns from one counter: the second core (a task below the sound and the screen)
// takes what its spare time allows and this one the rest. The pixels are exactly those of one core drawing them all.
static int s_tNext = 0;                             // the next block of columns
static float s_tZFar = 0.f;
static constexpr int TCOLS = 4;
MR_HOT static void terrainColumns() {
    const float zFar = s_tZFar;
    const Grid& gN = terrainNear();
    const Grid& gF = terrainFar();
    float maxH = fmaxf(gN.maxH, gF.maxH);
    const int wrapN = gridWrap(gN.ox, gN.N) | (gridWrap(gN.oz, gN.N) << 16);   // the windows' origins, wrapped (once)
    const int wrapF = gridWrap(gF.ox, gF.N) | (gridWrap(gF.oz, gF.N) << 16);
    const float topK = (maxH - cy) * F;                  // the stop test, multiplied out (no divide per sample)
    Smp s = Smp(), q = Smp();
    Probe pr = Probe(), pp = Probe();
    for (;;) {
        const int xb = __atomic_fetch_add(&s_tNext, TCOLS, __ATOMIC_RELAXED);
        if (xb >= W) break;
        const int xe = xb + TCOLS < W ? xb + TCOLS : W;
        for (int x = xb; x < xe; x++) {
            int y = s_bottom[x];
            const float ddx = dxC[x], ddz = dzC[x], hx = horX[x];
            const int mist0 = (int)hx - 10, mist1 = (int)hx + 18;   // the mist band's rows
            float z = 0.55f;
            // previous sample (for per-pixel interpolation)
            float pY = (float)H + 40.f, pz = z, pwx = cx + ddx * z, pwz = cz + ddz * z, pa = 600.f, pal = 0.f, plt = 0.5f, ph = cy - 2.f;
            uint8_t pmat = 0, psurf = 0, phalf = 68, pextra = 0; bool pfar = false;
            bool first = true, inFar = false;
            bool pHave = false;              // the previous sample's road distance, light and material are worked out
            bool pYok = true;                // ... and its screen row (a hidden one's is worked out only if needed)
            uint8_t zcC = 0; float zLo = 1e30f, zHi = -1.f;   // the depth code: worked out again only where it can change
            // How far this column's ray certainly stays inside the near cache's usable cells: no bounds test per sample
            // before that. The margins (a quarter cell, and a whole one more at the far side) are far beyond the rounding
            // of the sample's own cell (whichever way it is rounded), so the test would pass at every sample skipped.
            const float zSafe = nearSafeZ(gN, ddx, ddz);
            while (z < zFar && y > 0) {
                float wx = cx + ddx * z, wz = cz + ddz * z;
                bool far = inFar;
                if (!inFar) {
                    if (!probeAt(gN, wrapN, wx, wz, !(z < 45.f), pr, z >= zSafe)) { inFar = far = true; }
                }
                if (far) {
                    if (!probeAt(gF, wrapF, wx, wz, true, pr)) break;
                    const Cell& n = probeNearest(pr);
                    if (n.extra && n.extra < 0x80 && (n.mat & 15) < MAT_WATER) pr.h += n.extra * (0.35f + 0.65f * tex((int)(wx * 0.6f), (int)(wz * 0.6f)) * (1.f / 255.f));
                }
                const float A = (pr.h - cy) * F;
                float ys = 0.f;
                bool vis;
                if (first) {
                    ys = hx - A / z;
                    pY = fmaxf(ys, (float)H + 1.f); first = false; pp = pr; pHave = false; pYok = true; ph = pr.h; pfar = far;
                    vis = ys < y;
                } else {
                    // hidden behind what's drawn, for certain (margin far above rounding): no divide, no row
                    const float B = (hx - (float)y) * z;
                    if (B - A > 0.02f * z + (fabsf(A) + fabsf(B)) * 1e-6f) vis = false;
                    else { ys = hx - A / z; vis = ys < y; }
                }
                int yTop = vis ? iceil(ys) : 0;
                if (yTop < 0) yTop = 0;
                if (vis && yTop >= y) {
                    // above the drawn ground, but not by a whole row: nothing to draw. Its road distance, light and material
                    // are worked out only if the next sample draws (exactly the values they would have had now)
                    pY = ys; pYok = true; pHave = false;
                } else if (vis) {
                    if (!pYok) { pY = hx - (ph - cy) * F / pz; pYok = true; }      // exactly the row it would have had
                    for (int k = pHave ? 1 : 0; k < 2; k++) probeAttr(k ? pr : pp, k ? s : q);
                    if (s_cloudAmt > 0.f) { s.lt *= cloudK(wx, wz); if (!pHave) q.lt *= cloudK(pwx, pwz); }   // cloud shadows
                    if (!pHave) { pa = q.a; pal = q.al; plt = q.lt; pmat = q.mat; psurf = q.surf; phalf = q.half; pextra = q.extra; }
                    float span = pY - ys;
                    float inv = span > 0.001f ? 1.f / span : 0.f;
                    float fogNear = s_fog[clampi((int)pz, 0, 519)], fogFar = s_fog[clampi((int)z, 0, 519)];
                    const bool pRoad = pmat == MAT_ROAD || pmat == MAT_SHOULDER, cRoad = s.mat == MAT_ROAD || s.mat == MAT_SHOULDER;
                    // two roads side by side at different heights (the narrow shelf): the face between them is a cut wall
                    const float legDh = s.h - ph;
                    const bool legWall = pRoad && cRoad && fabsf(legDh) > 1.5f + 0.15f * (z - pz);
                    const float legLow = legDh > 0.f ? ph : s.h;
                    for (int yy = y - 1; yy >= yTop; yy--) {
                        float t = clampf((pY - yy) * inv, 0.f, 1.f);
                        float zz = pz + (z - pz) * t;
                        float wxx = pwx + (wx - pwx) * t, wzz = pwz + (wz - pwz) * t;
                        float aa = pa + (s.a - pa) * t;
                        float dal = s.al - pal; if (dal > 6.4f) dal -= 12.8f; else if (dal < -6.4f) dal += 12.8f;
                        float al = pal + dal * t; if (al < 0.f) al += 12.8f;
                        float lt = plt + (s.lt - plt) * t;
                        float hg = ph + (s.h - ph) * t;
                        // this spot of ground's own grain: only worked out where it matters (an edge between materials,
                        // fog, a reflection, mist); everywhere else it would change nothing
                        float sd = -1.f;
                        bool edge = s.mat != pmat || s.surf != psurf;
                        if (edge) sd = surfDith(wxx, wzz, zz);
                        bool useCur = edge ? t > sd : t > 0.5f;
                        uint8_t mat = useCur ? s.mat : pmat, surf = useCur ? s.surf : psurf;
                        float half = (useCur ? s.half : phalf) * 0.05f;
                        if (legWall) {
                            if (hg - legLow > 0.35f) { aa = half + 9.f; mat = MAT_ROCK; surf = SURF_ROCK; }
                        } else {
                            // a wall face rising beside the road is wall, not road: road paint only at the road's own height
                            float aaPix = fabsf(aa);
                            if (aaPix < half + 1.3f) {
                                if (pRoad != cRoad) {
                                    float roadH = pRoad ? ph : s.h;
                                    if (hg - roadH > 0.35f) { aa = (aa < 0.f ? -1.f : 1.f) * (half + 9.f); mat = pRoad ? s.mat : pmat; surf = pRoad ? s.surf : psurf; }
                                }
                            }
                        }
                        bool refl = false;
                        uint8_t c = groundPix(x, yy, wxx, wzz, aa, al, half, lt, zz, hg, mat, surf, useCur ? far : pfar, useCur ? s.extra : pextra, refl);
                        float fg = fogNear + (fogFar - fogNear) * t;
                        {                                                   // fog: the palette way, stepping to fogged twins
                            float fa = clampf((fg - 0.3f) * (1.f / 0.42f), 0.f, 1.f);
                            if (fa > 0.f) {
                                float f4 = fa * 4.f; int lv = (int)f4; float fr = f4 - lv;
                                if (fr > 0.86f) lv++;
                                else if (fr > 0.62f) { if (sd < 0.f) sd = surfDith(wxx, wzz, zz); if (sd < 0.5f) lv++; }   // the grain only in the seam
                                if (lv > 0) c = s_fogLut[lv > 4 ? 3 : lv - 1][c];
                                if (fa > 0.5f) refl = false;
                            }
                        }
                        int i = yy * W + x;
                        fb[i] = c;
                        if (!(zz >= zLo && zz < zHi)) {             // exactly zcode(zz): up a column depth only grows, and the
                            zcC = zcode(zz); zLo = zz;              // code only steps at known depths ((c + 2) / 11)^2
                            float kk = (zcC + 2) * (1.f / 11.f);
                            zHi = zcC >= 252 ? 1e30f : kk * kk * 0.999f;
                        }
                        zb[i] = (uint8_t)(zcC | (refl ? 1 : 0));
                        bool mistRow = s_mistOn && yy >= mist0 && yy < mist1;   // only the mist band's rows
                        if (s_gpat && (refl || mistRow)) { if (sd < 0.f) sd = surfDith(wxx, wzz, zz); s_gpat[i] = (uint8_t)(sd * 255.f); }
                    }
                    y = yTop;
                    pY = ys; pYok = true;
                    pa = s.a; pal = s.al; plt = s.lt; pmat = s.mat; psurf = s.surf; phalf = s.half; pextra = s.extra; pHave = true;
                } else {
                    pYok = false; pHave = false;            // its row and the rest only if the next sample draws
                }
                pz = z; pwx = wx; pwz = wz; ph = pr.h; pfar = far; pp = pr;
                // nothing beyond can rise above what is drawn: done (y <= hx - topK / z, multiplied out)
                if ((hx - (float)y) * z >= topK) break;
                z += far ? 0.6f + z * 0.045f : 0.12f + z * 0.038f;
            }
            ymin[x] = (uint8_t)clampi(y, 0, H);
        }
    }
}
#ifndef HOST
static TaskHandle_t s_tWorker = nullptr;
static SemaphoreHandle_t s_tDone = nullptr;
static void terrainWorker(void*) {
    for (;;) { ulTaskNotifyTake(pdTRUE, portMAX_DELAY); terrainColumns(); xSemaphoreGive(s_tDone); }
}
#endif
static void drawTerrain(float zFar) {
    s_tZFar = zFar;
    s_lwNear = 0.0999f * F;
    __atomic_store_n(&s_tNext, 0, __ATOMIC_RELEASE);
#ifndef HOST
    const bool help = s_tWorker != nullptr;
    if (help) xTaskNotifyGive(s_tWorker);               // (the notify and the take below are full barriers)
#endif
    terrainColumns();
#ifndef HOST
    if (help) xSemaphoreTake(s_tDone, portMAX_DELAY);  // its last block is done
#endif
}

// ================================================================================== panorama and sky
static float hFar[W + 2], hNear[W + 2];
static float s_skyPow[80], s_skyTT[80];
static float s_sunX, s_sunY, s_sunVis, s_lowSun;

// The ranges live in a ring around the whole horizon (1024 steps), refreshed a slice a frame and looked up by
// heading: turning costs nothing, and the land only morphs slowly with distance.
static constexpr int PAN_N = 1024;
static float* s_panFar = nullptr;
static float* s_panNear = nullptr;
static int s_panCur = 0;
static bool s_panFull = true;
static float s_panPeaks = -1.f; static bool s_panMesa = false; static float s_panMorph = 0.f;
__attribute__((noinline)) static void panoramaRefresh(int count) {   // once a frame: flash (not inlined into IRAM)
    const Scene& sc = g_scene;
    const Biome& A = biome(sc.biomeA); const Biome& B = biome(sc.biomeB);
    float peaks = A.peaks + (B.peaks - A.peaks) * sc.blend;
    bool mesa = (sc.blend < 0.5f ? sc.biomeA : sc.biomeB) == B_CANYON;
    float morph = sc.distance * 0.00015f;
    for (int n = 0; n < count; n++) {
        int k = s_panCur; s_panCur = (s_panCur + 1) & (PAN_N - 1);
        float u = k * (12.f / PAN_N);
        float mass = fbmP(u, morph, 12, 3, worldSeed() + 0x51);                   // broad massifs
        float r = 1.f - fabsf(2.f * fbmP(u * 3.f, morph + 3.f, 36, 2, worldSeed() + 0x52) - 1.f);   // ridged detail
        float hf = (mass - 0.38f) * 1.6f + r * r * 0.35f * mass;
        hf = fmaxf(0.f, hf) * peaks * 62.f;
        if (mesa) hf = floorf(hf / 9.f) * 9.f + 4.f * clampf(fmodf(hf, 9.f) - 6.f, 0.f, 1.f);
        float f2 = fbmP(u * 2.f, morph * 1.6f, 24, 3, worldSeed() + 0x53);
        s_panFar[k] = hf;
        s_panNear[k] = (f2 - 0.42f) * (10.f + peaks * 26.f);
    }
}
__attribute__((noinline)) static void computePanorama() {            // once a frame: flash (not inlined into IRAM)
    if (!s_panFar) { s_panFar = (float*)memSlow(PAN_N * sizeof(float)); s_panNear = (float*)memSlow(PAN_N * sizeof(float)); s_panFull = true; }   // read ~160x a frame: PSRAM is fine
    {   const Scene& sc = g_scene;
        const Biome& A = biome(sc.biomeA); const Biome& B = biome(sc.biomeB);
        float peaks = A.peaks + (B.peaks - A.peaks) * sc.blend;
        bool mesa = (sc.blend < 0.5f ? sc.biomeA : sc.biomeB) == B_CANYON;
        float morph = sc.distance * 0.00015f;
        if (fabsf(peaks - s_panPeaks) > 0.01f || mesa != s_panMesa || fabsf(morph - s_panMorph) > 0.02f) s_panFull = true;
        s_panPeaks = peaks; s_panMesa = mesa; s_panMorph = morph;
    }
    panoramaRefresh(s_panFull ? PAN_N : PAN_N / 8);
    s_panFull = false;
    float lift = (cy - journeyBase(cx, cz)) * F / 1800.f;
    const float toIdx = PAN_N / 6.2831853f;
    for (int x = -1; x <= W; x++) {
        int xi = clampi(x, 0, W - 1);
        float a = azC[xi] + (x - xi) / F;
        float f = a * toIdx;
        f -= PAN_N * floorf(f / PAN_N);
        int i0 = (int)f; float t = f - i0;
        int i1 = (i0 + 1) & (PAN_N - 1); i0 &= PAN_N - 1;
        float hf = s_panFar[i0] + (s_panFar[i1] - s_panFar[i0]) * t;
        float hn = s_panNear[i0] + (s_panNear[i1] - s_panNear[i0]) * t;
        hFar[x + 1] = fmaxf(0.f, hf * F / 96.f - lift);
        hNear[x + 1] = fmaxf(0.f, hn * F / 96.f - lift * 2.f);
    }
}

// once a frame, internal RAM only (no PSRAM to evict it from the cache): flash, paying for the terrain's shade bits in IRAM
__attribute__((noinline)) static void drawRidge(const float* hh, int far, float snowLine) {
    for (int x = 0; x < W; x++) {
        float h = hh[x + 1];
        int baseY = (int)horX[x] + (far ? 1 : 3);
        if (h <= 0.f) continue;
        float top = horX[x] - h;
        float slope = (hh[x + 2] - hh[x]) * 0.5f;
        float face = -slope * sideC[x];
        float lit = 0.5f + 0.3f * face / (1.f + fabsf(face));
        float u = angU(azC[x], 240);
        int y0 = clampi((int)ceilf(top), 0, H);
        int y1 = baseY < ymin[x] ? baseY : ymin[x];
        float snowDepth = h > snowLine ? (h - snowLine) * 0.55f : -1.f;
        for (int y = y0; y < y1; y++) {
            float d = y - top, depth = d / h;
            float g = tex((int)(u * 0.5f + d * 0.25f * (sideC[x] >= 0.f ? 1.f : -1.f)) + (far ? 17 : 0), (int)(d * 0.4f)) * (1.f / 255.f);
            float s = lit + (g - 0.5f) * 0.38f * (0.4f + 0.6f * (1.f - depth)) - depth * 0.3f;
            if (snowDepth > 0.f && d < snowDepth + g * 3.f) s = 0.95f;
            int lv = clampi((int)(s * 7.99f), 0, 7);
            if (d < 1.f && face > 0.15f) lv = clampi(lv + 2, 0, 7);
            fb[y * W + x] = (uint8_t)(P_MTN + (far ? 0 : 8) + lv);
            zb[y * W + x] = 254;
        }
    }
}

MR_HOT static void drawSkyAndPanorama() {
    const Scene& sc = g_scene;
    computePanorama();
    // fill between the far terrain and the horizon with distant hills
    for (int x = 0; x < W; x++) for (int y = (int)horX[x] + 1; y < ymin[x]; y++) { if (y < 0) continue; fb[y * W + x] = (uint8_t)(P_MTN + 3); zb[y * W + x] = 254; }
    float snowF = 26.f * F / 96.f;
    drawRidge(hNear, 0, 999.f);
    // the far range sits behind the near one: only where the sky still shows
    static uint8_t top[W];
    for (int x = 0; x < W; x++) {
        float hn = hNear[x + 1];
        int t = hn > 0.f ? (int)ceilf(horX[x] - hn) : (int)horX[x] + 3;
        if (t > ymin[x]) t = ymin[x];
        top[x] = (uint8_t)clampi(t, 0, H);
    }
    {
        for (int x = 0; x < W; x++) {
            float h = hFar[x + 1];
            if (h <= 0.f) continue;
            float tp = horX[x] - h;
            float slope = (hFar[x + 2] - hFar[x]) * 0.5f;
            float face = -slope * sideC[x];
            float lit = 0.5f + 0.3f * face / (1.f + fabsf(face));
            for (int y = clampi((int)ceilf(tp), 0, H); y < top[x]; y++) {
                float d = y - tp;
                float s = lit - d / h * 0.25f;
                if (h > snowF && d < (h - snowF) * 0.5f + 1.f) s = 0.92f;
                fb[y * W + x] = (uint8_t)(P_MTN + clampi((int)(s * 7.99f), 0, 7));
                zb[y * W + x] = 254;
            }
            int t2 = (int)ceilf(tp);
            if (t2 < top[x]) top[x] = (uint8_t)clampi(t2, 0, H);
        }
    }
    // sky (Planet's gradient + horizon glow + sun halo)
    float sunRel = wrapPi(sc.sunAz - cyaw);
    s_sunVis = (sc.sunElev > -0.12f ? 1.f : 0.f) * clampf(1.f - sc.cloud * 0.85f, 0.f, 1.f);
    s_lowSun = clampf(1.f - sc.sunElev / 0.5f, 0.f, 1.f) * (sc.sunElev > -0.15f ? 1.f : 0.f);
    s_sunX = W * 0.5f + tanf(clampf(sunRel, -1.4f, 1.4f)) * F;
    s_sunY = hor0 - tanf(sc.sunElev) * F + (s_sunX - W * 0.5f) * rollT;
    if (fabsf(sunRel) > 1.4f) s_sunX = sunRel > 0 ? 9999.f : -9999.f;
    for (int x = 0; x < W; x++) {
        float rel = wrapPi(sc.sunAz - azC[x]);
        float hglow = s_sunVis * s_lowSun / (1.f + rel * rel * 3.f);
        float skyH = horX[x] + 2.f;
        for (int y = 0; y < top[x]; y++) {
            int k = clampi((int)(y + 0.5f - (skyH - 78.f)), 0, 78);
            float base = s_skyPow[k], tt = s_skyTT[k];
            float halo = 0.f;
            if (s_sunVis > 0.f) { float dx = x - s_sunX, dy = y - s_sunY; halo = s_sunVis * 5.5f / (1.f + (dx * dx + dy * dy) * (1.f / 260.f)); }
            fb[y * W + x] = (uint8_t)(P_SKY + clampi(band(base + hglow * tt * 6.5f + halo, x, y), 0, 15));
            zb[y * W + x] = 255;
        }
    }
    // rainbow: a 42 degree circle round the point opposite the sun
    if (sc.rainbow > 0.05f && sc.night < 0.5f) {
        float antiAz = sc.sunAz + 3.14159f, antiEl = -sc.sunElev;
        // the band is 0.69..0.75 rad from the antisolar point: rows outside +-0.76 rad of its elevation can't be in it
        const float elLo = antiEl - 0.76f, elHi = antiEl + 0.76f;
        const float tHi = elHi < 1.55f ? tanf(elHi) : 1e6f, tLo = elLo > -1.55f ? tanf(elLo) : -1e6f;
        for (int x = 0; x < W; x++) {
            float da = wrapPi(azC[x] - antiAz);
            if (fabsf(da) > 0.76f) continue;
            int yA = (int)(horX[x] - tHi * F) - 2, yB = (int)(horX[x] - tLo * F) + 3;   // el <= elHi .. el >= elLo, with room
            if (yA < 0) yA = 0;
            for (int y = yA; y < ymin[x] && y < H && y < yB; y++) {
                if (zb[y * W + x] < 254) continue;
                float el = atanf((horX[x] - y) / F);
                float r = sqrtf(da * da + (el - antiEl) * (el - antiEl));
                if (r < 0.69f || r > 0.75f) continue;
                if (sc.rainbow * 0.75f < dith(x, y)) continue;
                fb[y * W + x] = (uint8_t)(P_SPECIAL + clampi((int)((r - 0.69f) / 0.06f * 7.f), 0, 6));
            }
        }
    }
}

static constexpr int CL_N = 512, CL_R = 26;
static uint8_t* s_cl = nullptr;                // cloud density around the horizon [angle][row]
static int s_clCur = 0;
static bool s_clFull = true;
__attribute__((noinline)) static void cloudRefresh(int count) {      // once a frame: flash (not inlined into IRAM)
    const Scene& sc = g_scene;
    for (int n = 0; n < count; n++) {
        int k = s_clCur; s_clCur = (s_clCur + 1) % CL_N;
        float u = k * (36.f / CL_N);
        for (int r = 0; r < CL_R; r++) {
            float v = r * 0.15f + sc.distance * 0.001f + s_t * 0.004f;
            float nn = (tex((int)(u * 3.556f), (int)(v * 8.f)) * 0.62f + tex((int)(u * 7.11f) + 21, (int)(v * 16.f) + 9) * 0.38f) * (1.f / 255.f);
            nn = (nn - 0.5f) * 1.5f + 0.5f;
            s_cl[k * CL_R + r] = (uint8_t)clampi((int)(nn * 255.f), 0, 255);
        }
    }
}
MR_HOT static void drawClouds() {                                 // Planet's banded pixel clouds
    const Scene& sc = g_scene;
    if (sc.cloud < 0.04f) return;
    const int CR = 26;
    float thresh = 0.92f - 0.62f * sc.cloud + 0.12f * s_night * (1.f - sc.cloud);
    float drift = s_t * 0.006f * (1.f + 2.f * sc.wind);
    float centre = CR * (0.42f + 0.2f * sc.storm);
    if (!s_cl) { s_cl = (uint8_t*)memSlow(CL_N * CL_R); s_clFull = true; }   // read ~2,000x a frame: PSRAM is fine
    if (!s_cl) return;
    cloudRefresh(s_clFull ? CL_N : CL_N / 8);
    s_clFull = false;
    const float toIdx = CL_N / 6.2831853f;
    for (int x = 0; x < W; x += 2) {
        float a = azC[x] + drift;
        float fi = a * toIdx; fi -= CL_N * floorf(fi / CL_N);
        const uint8_t* col = s_cl + ((int)fi % CL_N) * CL_R;
        float rel = wrapPi(sc.sunAz - a);
        float prox = s_sunVis / (1.f + rel * rel * 6.f);
        float prevD = -1.f;
        float n = 0.f;
        for (int y = 0; y < CR * 2; y++) {
            int yy = y + (int)(horX[x] - 70.f);
            if (yy < 0 || yy >= H) continue;
            float cyf = y * 0.5f;
            n = col[y >> 1] * (1.f / 255.f);
            float prof = clampf(1.f - fabsf(cyf - centre) / (CR * 0.6f), 0.f, 1.f);
            float d = n * 0.8f + prof * 0.35f - thresh;
            float dn = d;
            if (d <= 0.f) { prevD = d; continue; }
            float alpha = clampf(d * 11.f, 0.f, 1.f);
            float top = clampf((d - prevD) * 6.f, 0.f, 1.f);
            prevD = dn;
            for (int k = 0; k < 2; k++) {
                int xx = x + k;
                if (xx >= W) break;
                int i = yy * W + xx;
                if (zb[i] < 255) continue;
                if (alpha < 0.45f || (alpha < 0.7f && ((xx ^ yy) & 1))) continue;
                float light = 0.3f + top * 0.45f * (1.f - s_lowSun) + prox * 0.35f + (1.f - alpha) * 0.2f + s_lowSun * 0.25f * (1.f - cyf / CR);
                light *= 1.f - 0.4f * sc.rain - 0.3f * sc.storm;
                int lvl = clampi(band(light * 4.f, xx, yy), 0, 4) * 3 + 2;
                fb[i] = (uint8_t)(P_CLOUD + lvl);
            }
        }
    }
}

static constexpr int STAR_N = 1000;
static void drawNight() {
    const Scene& sc = g_scene;
    float n = s_night;
    if (n < 0.08f) return;
    uint32_t tw = (uint32_t)(s_t * 5.f);
    static float starAz[STAR_N], starEl[STAR_N]; static uint8_t starB[STAR_N]; static bool made = false;
    if (!made) {
        for (int k = 0; k < STAR_N; k++) {
            uint32_t h = hash32((uint32_t)k * 2654435761u ^ 0x57A2u);
            starAz[k] = (h & 0xFFFF) * (6.2831853f / 65536.f);
            float e = ((h >> 16) & 0x3FF) / 1023.f;
            starEl[k] = atanf(0.02f + e * 0.8f);              // evenly over the rows of sky, like the old per-pixel scan
            starB[k] = (uint8_t)(3 + (hash32(h) % 5));
        }
        made = true;
    }
    float dens = n * (1.f - sc.cloud * 0.8f) * (sc.biomeA == B_TUNDRA ? 1.f : 0.4f);
    int count = (int)(STAR_N * clampf(dens, 0.f, 1.f));
    for (int k = 0; k < count; k++) {
        float rel = wrapPi(starAz[k] - cyaw);
        if (fabsf(rel) > 0.8f) continue;
        float sx = W * 0.5f + tanf(rel) * F;
        int x = (int)sx;
        if ((unsigned)x >= (unsigned)W) continue;
        int y = (int)(horX[x] - tanf(starEl[k]) * F);
        if ((unsigned)y >= (unsigned)H) continue;
        int i = y * W + x;
        if (zb[i] != 255 || fb[i] >= P_CLOUD) continue;
        int b = starB[k];
        if ((hash32((uint32_t)k ^ tw) & 7u) == 0) b -= 3;
        fb[i] = (uint8_t)(P_SUN + clampi(b, 0, 7));
    }
    // moon
    float mrel = wrapPi(sc.sunAz + 3.14159f - cyaw);
    if (n > 0.3f && fabsf(mrel) < 1.2f) {
        float mx = W * 0.5f + tanf(mrel) * F, my = horX[0] - 40.f;
        for (int dy = -5; dy <= 5; dy++) for (int dx = -5; dx <= 5; dx++) {
            if (dx * dx + dy * dy > 22) continue;
            int x = (int)mx + dx, y = (int)my + dy;
            if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H || zb[y * W + x] != 255) continue;
            int b = (dx * 0.8f + dy * 0.4f > 2.6f) ? 5 : 7;
            if ((dx + 1) * (dx + 1) + (dy - 1) * (dy - 1) < 3) b = 5;
            fb[y * W + x] = (uint8_t)(P_SUN + b);
        }
    }
    // aurora: curtains folding over the northern sky
    if (sc.aurora > 0.05f) {
        for (int x = 0; x < W; x++) {
            float u = angU(azC[x], 96);
            float curtain = fbmP(u * 0.5f, s_t * 0.03f, 48, 3, 0xA0A0u);
            curtain = clampf((curtain - 0.42f) * 3.f, 0.f, 1.f) * sc.aurora;
            if (curtain <= 0.f) continue;
            float base = horX[x] - 18.f - 10.f * vnoiseP(u * 0.3f, s_t * 0.02f, 29, 0xA1u);
            float streak = vnoiseP(u * 4.f, s_t * 0.2f, 384, 0xA2u);
            for (int y = (int)(base - 40.f); y < (int)base; y++) {
                if (y < 0 || y >= H) continue;
                int i = y * W + x;
                if (zb[i] != 255) continue;
                float v = (y - (base - 40.f)) / 40.f;
                float k = curtain * v * v * (0.5f + streak);
                if (k < sdith((int)floorf(azC[x] * F), (int)horX[x] - y, s_t, 0.6f) * 0.9f) continue;
                fb[i] = (uint8_t)(P_SPECIAL + clampi((int)(k * 7.f + (v < 0.5f ? 4.f : 0.f)), 1, 7));
            }
        }
    }
}

static void drawSun() {
    if (s_sunVis <= 0.f || s_sunX < -12 || s_sunX > W + 12 || s_sunY < -12) return;
    int sx = (int)lroundf(s_sunX), sy = (int)lroundf(s_sunY);
    for (int dy = -8; dy <= 8; dy++) for (int dx = -8; dx <= 8; dx++) {
        float d = sqrtf((float)(dx * dx + dy * dy));
        int x = sx + dx, y = sy + dy;
        if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) continue;
        int i = y * W + x;
        if (zb[i] != 255) continue;
        if (d < 4.2f) fb[i] = P_SUN + 7;
        else if (d < 7.5f && (1.f - (d - 4.2f) / 3.3f) > dith(x, y)) fb[i] = P_SUN + 5;
    }
}

// ================================================================================== props
static inline void putZ(int x, int y, uint8_t c, uint8_t zc) {
    if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
    int i = y * W + x;
    if (zb[i] <= zc) return;
    fb[i] = c; zb[i] = zc;
}

// A template pixel's colour depends only on its byte, the headlight step (lightAdd) and the autumn leaf (alt): worked
// out the first time each byte turns up for that lighting, then looked up. (0 = not yet: no sprite colour is 0.)
static uint8_t s_tplCol[256];
static int s_tplKey = -1000;
__attribute__((noinline)) static uint8_t tplColour(uint8_t v, int lightAdd, bool alt) {   // flash: only on a table miss
    int m = v >> 4, sh = (v & 15) + lightAdd;
    uint8_t c;
    switch (m) {
        case TM_LEAF:  c = alt ? (uint8_t)(P_LEAF2 + clampi(sh / 2, 0, 7)) : (uint8_t)(P_LEAF + clampi(sh, 0, 15)); break;
        case TM_LEAF2: c = (uint8_t)(P_LEAF2 + clampi(sh / 2, 0, 7)); break;
        case TM_BARK:  c = (uint8_t)(P_BARK + clampi(sh / 2, 0, 7)); break;
        case TM_ROCK:  c = (uint8_t)(P_ROCK + clampi(sh, 0, 15)); break;
        case TM_SNOW:  c = (uint8_t)(P_SNOW + clampi(sh / 2, 0, 7)); break;
        case TM_FLOWER: c = (uint8_t)(P_FLOWER + (v & 7)); break;
        case TM_WALL:  c = (uint8_t)(P_ROCK + clampi(sh + 2, 0, 15)); break;
        case TM_ROOF:  c = (uint8_t)(P_ROCK + clampi(sh - 4, 0, 15)); break;
        case TM_GLASS: c = P_WINDOW; break;
        case TM_SIGN:  c = (v & 15) > 12 ? P_SIGN_W : P_SIGN_G; break;
        case TM_SIGNTXT: c = P_SIGN_W; break;
        case TM_SIGNY: c = (uint8_t)(P_LINE_Y + clampi(sh / 4, 0, 3)); break;   // lit like the road paint: it shines in the headlights
        case TM_INK:   c = (uint8_t)(P_ROAD + 1); break;
        default:       c = (uint8_t)(P_SNOW + 7); break;
    }
    return c;
}
// a lit template, scaled. base: screen row of its foot at column sx.
MR_HOT static void blitTpl(uint8_t id, float sx, float baseY, float pxH, float depth, bool mirror, bool alt, float headK) {
    const Tpl& t = tpl(id);
    if (!t.px || pxH < 1.5f) return;
    float sc = pxH / t.h;
    float pxW = t.w * sc;
    int x0 = (int)floorf(sx - t.ax * sc), x1 = (int)ceilf(x0 + pxW);
    if (x1 < 0 || x0 >= W) return;
    uint8_t zc = zcode(depth);
    float fog = s_fog[clampi((int)depth, 0, 519)];
    float inv = 1.f / sc;
    int lightAdd = (int)(headK * 6.f) - (s_night > 0.5f ? 3 : 0);
    // fogTwin(c, amt, grain) with amt fixed for the whole sprite: two possible levels, the seam picks by grain < 0.5,
    // which for the 4x4 pattern is BAYER <= 7. The same twins, worked out once instead of per pixel.
    const uint8_t* fogA = nullptr; const uint8_t* fogB = nullptr; int fogMode = 0;   // 0 none, 1 always B, 2 B in the seam
    if (fog > 0.3f) {
        float f = clampf((fog - 0.3f) * 2.f, 0.f, 1.f) * 4.f; int lv = (int)f; float fr = f - lv;
        int lB = lv + 1;
        fogA = lv <= 0 ? nullptr : s_fogLut[lv > 4 ? 3 : lv - 1];
        fogB = lB <= 0 ? nullptr : s_fogLut[lB > 4 ? 3 : lB - 1];
        fogMode = fr > 0.86f ? 1 : (fr > 0.62f ? 2 : 3);
    }
    const int key = lightAdd * 2 + (alt ? 1 : 0);
    if (key != s_tplKey) { memset(s_tplCol, 0, sizeof s_tplCol); s_tplKey = key; }
    // The template row for each screen row: the same in every column whose top row (y0) is the same, so worked out
    // again only when y0 changes (once a sprite unless the picture is rolled). A column draws rows below
    // y0 + (int)pxH + 2 only (by < y0 + 1 + pxH), so that is as far as it's needed.
    int16_t rowTy[H];
    int tabY0 = -(1 << 30);
    const int rowsSpan = pxH < (float)H ? (int)pxH + 2 : (1 << 20);       // (a sprite taller than the picture: every row)
    for (int x = x0 > 0 ? x0 : 0; x < x1 && x < W; x++) {
        int tx = (int)((x - x0) * inv);
        if (tx >= t.w) tx = t.w - 1;
        if (mirror) tx = t.w - 1 - tx;
        float by = baseY + (x - sx) * rollT;
        int y0 = (int)floorf(by - pxH);
        if (y0 != tabY0) {
            tabY0 = y0;
            int e = y0 > H ? H : y0 + rowsSpan; if (e > H) e = H;
            for (int y = y0 > 0 ? y0 : 0; y < e; y++) { int ty = (int)((y - y0) * inv); rowTy[y] = (int16_t)(ty >= t.h ? t.h - 1 : ty); }
        }
        for (int y = y0 > 0 ? y0 : 0; y < (int)by && y < H; y++) {
            int i = y * W + x;
            if (zb[i] <= zc) continue;                       // hidden: don't fetch the sprite's pixel at all
            int ty = rowTy[y];
            uint8_t v = t.px[ty * t.w + tx];
            if (!v) continue;
            uint8_t c = s_tplCol[v];
            if (!c) c = s_tplCol[v] = tplColour(v, lightAdd, alt);
            if (fogMode) {                                      // the palette way: the sprite steps to its fogged twins
                const uint8_t* L = fogMode == 1 ? fogB : (fogMode == 2 && BAYER[((ty & 3) << 2) | (tx & 3)] <= 7 ? fogB : fogA);
                if (L) c = L[c];                                // (its seam keyed to the sprite itself)
            }
            fb[i] = c; zb[i] = zc;
        }
    }
}

// A prop's shadow on the ground under it: a flattened ellipse, offset away from the sun, that steps the ground one
// shade darker (the reflection table: same ramp, darker). Only ground at about the prop's own depth (nothing nearer,
// nothing far behind), drawn before the prop itself. Soft edge: the outer part dithered.
static bool s_propSh = false;
static float s_propShX = 0.f, s_propShY = 0.f;
__attribute__((noinline)) static void propShadow(uint8_t id, float sx, float sy, float pxH, float dep) {
    const Tpl& t = tpl(id);
    if (!t.px) return;
    const float rx = t.w * (pxH / t.h) * 0.42f;
    if (rx < 1.5f) return;
    const float ry = rx * 0.28f + 0.5f;
    const float ex = sx + s_propShX * rx, ey = sy - 0.5f + s_propShY * ry;
    const int zc = zcode(dep);
    const int x0 = clampi((int)floorf(ex - rx), 0, W), x1 = clampi((int)ceilf(ex + rx), 0, W);
    const int y0 = clampi((int)floorf(ey - ry), 0, H), y1 = clampi((int)ceilf(ey + ry), 0, H);
    const float irx = 1.f / rx, iry = 1.f / ry;
    for (int y = y0; y < y1; y++) {
        const float v = (y + 0.5f - ey) * iry;
        for (int x = x0; x < x1; x++) {
            const float u = (x + 0.5f - ex) * irx, r2 = u * u + v * v;
            if (r2 >= 1.f) continue;
            const int i = y * W + x;
            const int zp = zb[i] & ~1;
            if (zp >= 254 || zp > zc + 8 || zp < zc - 8) continue;
            if (r2 > 0.6f && (r2 - 0.6f) * 2.5f > dith(x, y)) continue;
            fb[i] = s_refl[fb[i]];
        }
    }
}

static float headAt(float lat, float depth) {               // headlight on a prop
    if (s_lights < 0.02f || depth > 70.f) return 0.f;
    float k = lat / depth;
    float c = 1.f - k * k / 0.17f;
    return c > 0.f ? s_lights * c * fminf(1.f, 14.f / (depth + 4.f)) * s_night : 0.f;
}

static inline float sq(float v) { return v * v; }
extern float g_fallsNear;                           // the waterfall roar's level (audio)
static inline uint8_t fogged(uint8_t c, float dep, int x, int y);
static void line3(float ax, float ay, float az, float bx, float by, float bz, uint8_t col, int thick);
static inline bool roughlyInView(float x, float z, float maxD);
// ---- waterfalls: a lip cell (terrain marks it) and the lowest ground within 15 m down the face below it: a sheet of
// white water streaming down between them, foam at its foot. Drawn a little in front of the face it runs down.
static float s_fallX[4], s_fallZ[4];
static int s_fallN = 0;
static void drawFall(const Grid& g, int i, int j) {
    const float x0 = i * g.cell, z0 = j * g.cell;
    for (int k = 0; k < s_fallN; k++) if (fabsf(s_fallX[k] - x0) < 12.f && fabsf(s_fallZ[k] - z0) < 12.f) return;   // one a cliff
    const Cell& c = g.c[gridWrap(j, g.N) * g.N + gridWrap(i, g.N)];
    float nx = ((c.nrm >> 4) - 8) * 0.125f, nz = ((c.nrm & 15) - 8) * 0.125f;        // the normal leans downhill
    float nl = sqrtf(nx * nx + nz * nz);
    if (nl < 0.2f) return;
    nx /= nl; nz /= nl;
    // the lip may be anywhere on the face: up the face to its top edge (where the climb flattens out)
    float top = c.h * 0.1f, tx = x0, tz = z0;
    for (int k = 1; k <= 8; k++) {
        int ii = i - (int)floorf(nx * k + 0.5f), jj = j - (int)floorf(nz * k + 0.5f);
        if (ii < g.ox || jj < g.oz || ii >= g.ox + g.N || jj >= g.oz + g.N) break;
        const Cell& o = g.c[gridWrap(jj, g.N) * g.N + gridWrap(ii, g.N)];
        float oh = o.h * 0.1f;
        if (oh < top + 0.6f) break;                                   // the top: the climb stops
        top = oh; tx = ii * g.cell; tz = jj * g.cell;
    }
    float bot = c.h * 0.1f, bx = x0, bz = z0;
    for (int k = 1; k <= 6; k++) {
        int ii = i + (int)floorf(nx * k + 0.5f), jj = j + (int)floorf(nz * k + 0.5f);
        if (ii < g.ox || jj < g.oz || ii >= g.ox + g.N || jj >= g.oz + g.N) break;
        const Cell& o = g.c[gridWrap(jj, g.N) * g.N + gridWrap(ii, g.N)];
        if ((o.mat & 15) == MAT_ROAD || (o.mat & 15) == MAT_SHOULDER) break;
        float oh = o.h * 0.1f;
        if (oh < bot) { bot = oh; bx = ii * g.cell; bz = jj * g.cell; }
    }
    if (top - bot < 5.f) return;
    if (s_fallN < 4) { s_fallX[s_fallN] = x0; s_fallZ[s_fallN] = z0; s_fallN++; }
    float sxT, syT, dT, sxB, syB, dB;
    if (!renderProject(tx, top + 0.3f, tz, sxT, syT, dT) || !renderProject(bx, bot, bz, sxB, syB, dB)) return;
    float dist = sqrtf(sq(x0 - cx) + sq(z0 - cz));
    g_fallsNear = fmaxf(g_fallsNear, clampf(1.f - dist * (1.f / 160.f), 0.f, 1.f));
    int y0 = (int)ceilf(syT), y1 = (int)syB;
    if (y1 <= y0 || y1 - y0 > 2 * H) return;
    const float tt = g_scene.t;
    const float inv = 1.f / (float)(y1 - y0);
    const float drop = top - bot;
    int ya = y0 < 0 ? 0 : y0, yb = y1 + 3 > H ? H : y1 + 3;
    for (int y = ya; y < yb; y++) {
        float v = (y - y0) * inv;                                     // 0 at the lip, 1 at the foot (a little past: foam)
        float vc = v > 1.f ? 1.f : v;
        float sx = sxT + (sxB - sxT) * vc, dep = dT + (dB - dT) * vc;
        if (dep < 1.f) continue;
        float hw = (1.3f + 0.9f * vc + (v > 0.85f ? (v - 0.85f) * 9.f : 0.f)) * F / dep;   // it spreads, and foams at the foot
        uint8_t zc = zcode(fmaxf(fminf(dep - 2.5f, dep * 0.8f), 0.6f));   // in front of the face it runs down (a face bulges)
        int xa = (int)(sx - hw), xb = (int)(sx + hw);
        if (xa < 0) xa = 0;
        if (xb > W - 1) xb = W - 1;
        float m = vc * drop * 2.2f - tt * 7.f;                        // streaks running down, about 7 m/s
        for (int x = xa; x <= xb; x++) {
            int i2 = y * W + x;
            if (y >= s_bottom[x] || zb[i2] <= zc) continue;
            float ux = (x - sx) / (hw + 0.5f);                        // -1..1 across
            uint32_t hh = hash32((uint32_t)(int)((ux + 1.f) * 5.f) * 0x9E3779B1u ^ (uint32_t)(int)floorf(m + ux * 0.7f) * 0x85EBCA77u);
            int lv = 5 + (int)(hh & 3) - (fabsf(ux) > 0.8f ? 2 : 0);
            uint8_t col = v > 0.85f || (hh & 12) == 12 ? (uint8_t)(P_SNOW + clampi(lv + 1, 0, 7)) : (uint8_t)(P_WATER + clampi(lv, 0, 7));
            fb[i2] = fogged(col, dep, x, y); zb[i2] = zc;
        }
    }
}

// ---- farms: pastures (terrainPlot use 3) get a post-and-rail fence round their edge and a few cattle. Posts stand
// only where the pasture is (flat, off the road): the fence follows it.
static void drawFarm() {
    const float R = 130.f;
    const int i0 = (int)floorf((cx - R) * (1.f / PLOT_M)), i1 = (int)floorf((cx + R) * (1.f / PLOT_M));
    const int j0 = (int)floorf((cz - R) * (1.f / PLOT_M)), j1 = (int)floorf((cz + R) * (1.f / PLOT_M));
    const uint8_t col = (uint8_t)(P_BARK + clampi((int)(s_light[0x88] * 6.f), 1, 5));
    const uint8_t rc = (uint8_t)(P_BARK + clampi((int)(s_light[0x88] * 6.f) + 1, 1, 6));
    bool any = false;
    for (int pj = j0; pj <= j1; pj++) for (int pi = i0; pi <= i1; pi++) {
        if ((terrainPlot(pi, pj) & 0xE0) != 0xE0) continue;      // pastures only
        any = true;
        if (!roughlyInView(pi * PLOT_M + PLOT_M * 0.5f, pj * PLOT_M + PLOT_M * 0.5f, R + 45.f)) continue;
        for (int side = 0; side < 4; side++) {                   // the fence (field.cpp: where it stands, what's burst)
            float px = 0.f, pz = 0.f, py = 0.f; bool prev = false;
            for (int k = 0; k <= FENCE_POSTS; k++) {
                float x, z;
                bool on = fieldFencePost(pi, pj, side, k, x, z) && sq(x - cx) + sq(z - cz) < R * R;
                if (!on) { prev = false; continue; }
                const bool burstL = k > 0 && fieldFenceBroken(pi, pj, side, k - 1), burstR = k < FENCE_POSTS && fieldFenceBroken(pi, pj, side, k);
                float y = terrainHeight(x, z);
                float sx, sy, d;
                if (renderProject(x, y, z, sx, sy, d)) {
                    if (!(burstL && burstR)) line3(x, y - 0.1f, z, x, y + 1.25f, z, col, d < 18.f ? 2 : 1);   // (a post with both spans gone went too)
                    if (prev && !burstL) {
                        line3(px, py + 0.55f, pz, x, y + 0.55f, z, rc, 1);
                        line3(px, py + 1.05f, pz, x, y + 1.05f, z, rc, 1);
                    }
                }
                px = x; pz = z; py = y; prev = true;
            }
        }
    }
    if (!any) return;
    Cow cows[24];
    const int n = fieldCows(cx, cz, 150.f, g_scene.t, cows, 24);  // the herds
    for (int k = 0; k < n; k++) {
        const Cow& c = cows[k];
        float sx, sy, d;
        if (!renderProject(c.x, terrainHeight(c.x, c.z), c.z, sx, sy, d) || d < 1.f) continue;
        float pxH = 1.5f * F / d;
        if (pxH < 2.f) continue;
        blitTpl(c.pose ? T_COW1 : T_COW0, sx, sy + 1.f, pxH, d, sinf(c.heading - cyaw) < 0.f, false, headAt((c.x - cx) * rx + (c.z - cz) * rz, d));
    }
}

static void drawVegetation() {
    s_fallN = 0; g_fallsNear = 0.f;
    const Grid& g = terrainNear();
    if (!g.c) return;
    bool snowy = g_scene.biomeA == B_TUNDRA || g_scene.biomeA == B_ALPINE || g_scene.snow > 0.3f;
    bool autumn = (g_scene.blend < 0.5f ? g_scene.biomeA : g_scene.biomeB) == B_AUTUMN;
    float sunRel = g_scene.sunAz;
    float R = 125.f;
    float lx = cx + (fx - rx) * R, lz = cz + (fz - rz) * R, qx = cx + (fx + rx) * R, qz = cz + (fz + rz) * R;
    int i0 = (int)floorf(fminf(cx, fminf(lx, qx)) * g.inv) - 1, i1 = (int)ceilf(fmaxf(cx, fmaxf(lx, qx)) * g.inv) + 1;
    int j0 = (int)floorf(fminf(cz, fminf(lz, qz)) * g.inv) - 1, j1 = (int)ceilf(fmaxf(cz, fmaxf(lz, qz)) * g.inv) + 1;
    if (i0 < g.ox + 1) i0 = g.ox + 1;
    if (j0 < g.oz + 1) j0 = g.oz + 1;
    if (i1 > g.ox + g.N - 1) i1 = g.ox + g.N - 1;
    if (j1 > g.oz + g.N - 1) j1 = g.oz + g.N - 1;
    for (int j = j0; j < j1; j++) {
        for (int i = i0; i < i1; i++) {
            const Cell& c = g.c[gridWrap(j, g.N) * g.N + gridWrap(i, g.N)];
            uint8_t t = c.extra & 15;
            uint8_t m = c.mat & 15;
            if (c.extra == 0x80 && m == MAT_ROCK) { drawFall(g, i, j); continue; }   // a waterfall's lip
            if (!t || t >= VEG_N || m == MAT_ROAD || m == MAT_SHOULDER || m == MAT_WATER || m == MAT_LOT) continue;
            float wx0 = (i + 0.5f) * g.cell - cx, wz0 = (j + 0.5f) * g.cell - cz;
            float d0 = wx0 * fx + wz0 * fz;
            if (d0 < 0.5f || d0 > 125.f) continue;
            float l0 = wx0 * rx + wz0 * rz;
            if (fabsf(l0) > d0 * 0.95f + 6.f) continue;
            Veg v;
            if (!vegAt(i, j, v)) continue;
            float sx, sy, dep;
            if (!renderProject(v.x, v.y, v.z, sx, sy, dep)) continue;
            float pxH = v.size * F / dep;
            if (pxH < 2.5f) continue;
            {   int bx = (int)sx, by = (int)sy - 1, ty = (int)(sy - pxH * 0.7f);   // hidden behind nearer land?
                uint8_t zc = zcode(dep);
                if ((unsigned)bx < (unsigned)W && (unsigned)ty < (unsigned)H && (unsigned)by < (unsigned)H && zb[by * W + bx] < zc && zb[ty * W + bx] < zc) continue; }
            uint8_t id;
            switch (v.type) {
                case VEG_PINE: id = snowy ? T_PINESNOW : (uint8_t)(T_PINE0 + v.var % 3); break;
                case VEG_BROAD: id = (uint8_t)(T_BROAD0 + (v.var & 1)); break;
                case VEG_REDWOOD: id = T_REDWOOD; break;
                case VEG_BUSH: id = T_BUSH; break;
                case VEG_CACTUS: id = T_CACTUS; break;
                case VEG_SNAG: id = T_SNAG; break;
                case VEG_BOULDER: id = T_BOULDER; pxH *= 0.65f; break;
                default: id = T_FLOWERS; if (dep > 30.f) continue; break;
            }
            if (s_propSh && v.type != VEG_FLOWERS) propShadow(id, sx, sy + 1.f, pxH, dep);
            float az = cyaw + atanf((sx - W * 0.5f) / F);
            bool mirror = sinf(wrapPi(sunRel - az)) < 0.f;
            blitTpl(id, sx, sy + 1.f, pxH, dep, mirror, autumn && (v.var & 2), headAt(l0, d0));
        }
    }
}

static void drawSignText(int x0, int y0, int w, int h, uint8_t zc) {
    const Junction* j = roadJunction();
    if (!j || !j->active || w < 30) return;
    char l[16], r[16];
    bool armLeft = j->armSide < 0;
    snprintf(l, sizeof l, "<%s", biome(armLeft ? j->destArm : j->destMain).sign);
    snprintf(r, sizeof r, "%s>", biome(armLeft ? j->destMain : j->destArm).sign);
    int sc = w > 70 ? 2 : 1;
    font3(fb, W, H, x0 + 2, y0 + 2, l, P_SIGN_W, 0, sc);
    if (h > 14 * sc) font3(fb, W, H, x0 + w - font3Width(r, sc) - 2, y0 + 2 + 7 * sc, r, P_SIGN_W, 0, sc);
    (void)zc;
}

static void drawSignAndStore() {
    const RoadSign* s = roadSign();
    if (s && s->active) {
        float h = terrainHeight(s->x, s->z);
        float sx, sy, d;
        if (renderProject(s->x, h, s->z, sx, sy, d) && d < 160.f) {
            float pw = 4.4f * F / d, ph = 2.0f * F / d, post = 2.2f * F / d;
            uint8_t zc = zcode(d);
            int x0 = (int)(sx - pw * 0.5f), y0 = (int)(sy - post - ph);
            float hk = headAt(0.f, d);
            uint8_t g = hk > 0.3f ? P_SIGN_W : P_SIGN_G;
            for (int y = y0; y < (int)(sy - post); y++) for (int x = x0; x < (int)(x0 + pw); x++) {
                bool edge = y == y0 || y == (int)(sy - post) - 1 || x == x0 || x == (int)(x0 + pw) - 1;
                putZ(x, y, edge ? P_SIGN_W : (hk > 0.6f ? P_SIGN_G : g == P_SIGN_W ? P_SIGN_G : P_SIGN_G), zc);
            }
            for (int y = (int)(sy - post); y < (int)sy; y++) { putZ((int)(x0 + pw * 0.2f), y, P_BLACK, zc); putZ((int)(x0 + pw * 0.8f), y, P_BLACK, zc); }
            drawSignText(x0, y0, (int)pw, (int)ph, zc);
        }
    }
    const MotorSign* ms = roadMotorSign();                // MANTIS MOTORS, a quarter mile: the arrow points at its side
    if (ms && ms->active) {
        float h = terrainHeight(ms->x, ms->z);
        float sx, sy, d;
        if (renderProject(ms->x, h, ms->z, sx, sy, d) && d < 260.f)
            blitTpl(ms->travelSide < 0 ? T_MMSIGN_L : T_MMSIGN, sx, sy + 1.f, 4.3f * F / d, d, false, false, headAt((ms->x - cx) * rx + (ms->z - cz) * rz, d) * 1.5f);
    }
    const Store* st = roadStore();
    if (st && st->active) {
        float h = terrainHeight(st->x, st->z);
        float sx, sy, d;
        if (renderProject(st->x, h, st->z, sx, sy, d) && d < 460.f) blitTpl(T_STORE, sx, sy + 1.f, 13.f * F / d, d, false, false, 0.f);
    }
}

// ================================================================================== trestles and caution signs
// Drawn from the road's own nodes, where the road engine built a deck (RN_BRIDGE) or a level crossing (RN_CAUTION).
// Flash code: it only does anything with a trestle or a sign in view.
static inline float rsqrtF(float v) {                 // 1/sqrt(v): two Newton steps (decks: depth codes and planks)
    uint32_t i; memcpy(&i, &v, 4); i = 0x5f3759dfu - (i >> 1);
    float r; memcpy(&r, &i, 4);
    r = r * (1.5f - 0.5f * v * r * r);
    return r * (1.5f - 0.5f * v * r * r);
}
struct CV { float lat, up, dep, u; };                // a point in camera space, and a texture coordinate
struct SV { float x, y, w, uw; };                    // on screen: 1/depth and u/depth interpolate linearly
static constexpr float NEAR_D = 0.4f;
static inline CV camPt(float wx, float wy, float wz, float u) {
    float dx = wx - cx, dz = wz - cz;
    CV v; v.lat = dx * rx + dz * rz; v.up = wy - cy; v.dep = dx * fx + dz * fz; v.u = u;
    return v;
}
static inline CV lerpCV(const CV& a, const CV& b, float t) {
    CV v; v.lat = a.lat + (b.lat - a.lat) * t; v.up = a.up + (b.up - a.up) * t; v.dep = a.dep + (b.dep - a.dep) * t; v.u = a.u + (b.u - a.u) * t;
    return v;
}
static inline SV projCV(const CV& v) {
    float iw = 1.f / v.dep;
    SV o; o.x = W * 0.5f + v.lat * iw * F; o.y = hor0 + (o.x - W * 0.5f) * rollT - v.up * iw * F; o.w = iw; o.uw = v.u * iw;
    return o;
}
static inline uint8_t zcodeW(float w, float& dep) {   // the depth code from 1/depth (as zcode)
    float r = rsqrtF(w); dep = r * r;
    float c = r * 11.f;
    return (uint8_t)((int)(c > 252.f ? 252.f : c) & ~1);
}
static inline uint8_t fogged(uint8_t c, float dep, int x, int y) {   // the palette way, as the sprites
    float f = s_fog[clampi((int)dep, 0, 519)];
    return f > 0.3f ? fogTwin(c, clampf((f - 0.3f) * 2.f, 0.f, 1.f), dith(x, y)) : c;
}
// kind 0: deck planks (shade + stripes along u), 1: plain timber. The deck wins a tie with the ground it sits on (at the
// abutments the road's own cells are at the deck's height): two depth codes nearer.
static void fillTri(const SV& a, const SV& b, const SV& c, int kind, int shade) {
    float area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    if (fabsf(area) < 1e-3f) return;
    int x0 = clampi(ifloor(fminf(a.x, fminf(b.x, c.x))), 0, W - 1), x1 = clampi(iceil(fmaxf(a.x, fmaxf(b.x, c.x))), 0, W - 1);
    int y0 = clampi(ifloor(fminf(a.y, fminf(b.y, c.y))), 0, H - 1), y1 = clampi(iceil(fmaxf(a.y, fmaxf(b.y, c.y))), 0, H - 1);
    if (x0 > x1 || y0 > y1) return;
    const float ia = 1.f / area;
    const float dA = -(c.y - b.y) * ia, dB = -(a.y - c.y) * ia, dC = -(b.y - a.y) * ia;   // weights' step per pixel in x
    for (int y = y0; y <= y1; y++) {
        float py = y + 0.5f, px = x0 + 0.5f;
        float lA = ((c.x - b.x) * (py - b.y) - (c.y - b.y) * (px - b.x)) * ia;
        float lB = ((a.x - c.x) * (py - c.y) - (a.y - c.y) * (px - c.x)) * ia;
        float lC = ((b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x)) * ia;
        for (int x = x0; x <= x1; x++, lA += dA, lB += dB, lC += dC) {
            if (lA < 0.f || lB < 0.f || lC < 0.f || y >= s_bottom[x]) continue;
            float w = lA * a.w + lB * b.w + lC * c.w;
            if (w <= 0.f) continue;
            float dep; uint8_t zc = zcodeW(w, dep);
            zc = zc > 2 ? (uint8_t)(zc - 2) : 0;
            int i = y * W + x;
            if (zb[i] <= zc) continue;
            int lv = shade;
            if (kind == 0) {
                float pu = (lA * a.uw + lB * b.uw + lC * c.uw) * dep * 3.125f;   // planks 0.32 m wide, across the road
                int pi = ifloor(pu); float frc = pu - pi;
                lv += (pi & 1) ? 0 : 1;
                if (frc < 0.14f) lv -= 2;                                          // the gap between two planks
            }
            fb[i] = fogged(kind == 2 ? (uint8_t)(P_ROCK + clampi(lv + (((x >> 1) ^ (y * 3 >> 2)) & 1), 0, 15))   // rock: a grain
                         : kind == 3 ? (uint8_t)(P_ROAD + clampi(lv, 0, 15))                                    // concrete
                                     : (uint8_t)(P_BARK + clampi(lv, 0, 7)), dep, x, y);
            zb[i] = zc;
        }
    }
}
// a convex polygon (camera space), cut at the near plane, as a fan
static void fillPoly(const CV* v, int n, int kind, int shade) {
    CV o[8]; int m = 0;
    for (int k = 0; k < n && m < 7; k++) {
        const CV& p = v[k]; const CV& q = v[(k + 1) % n];
        bool pin = p.dep >= NEAR_D, qin = q.dep >= NEAR_D;
        if (pin) o[m++] = p;
        if (pin != qin) o[m++] = lerpCV(p, q, (NEAR_D - p.dep) / (q.dep - p.dep));
    }
    if (m < 3) return;
    SV sv[8];
    for (int k = 0; k < m; k++) sv[k] = projCV(o[k]);
    for (int k = 1; k + 1 < m; k++) fillTri(sv[0], sv[k], sv[k + 1], kind, shade);
}
static void line3(float ax, float ay, float az, float bx, float by, float bz, uint8_t col, int thick) {
    CV p = camPt(ax, ay, az, 0.f), q = camPt(bx, by, bz, 0.f);
    if (p.dep < NEAR_D && q.dep < NEAR_D) return;
    if (p.dep < NEAR_D) p = lerpCV(p, q, (NEAR_D - p.dep) / (q.dep - p.dep));
    else if (q.dep < NEAR_D) q = lerpCV(q, p, (NEAR_D - q.dep) / (p.dep - q.dep));
    SV a = projCV(p), b = projCV(q);
    float dx = b.x - a.x, dy = b.y - a.y;
    int n = (int)fmaxf(fabsf(dx), fabsf(dy)) + 1;
    if (n > 480) n = 480;
    float inv = 1.f / n;
    for (int k = 0; k <= n; k++) {
        float t = k * inv;
        int x = ifloor(a.x + dx * t), y = ifloor(a.y + dy * t);
        if ((unsigned)y >= (unsigned)H) continue;
        float w = a.w + (b.w - a.w) * t;
        if (w <= 0.f) continue;
        float dep; uint8_t zc = zcodeW(w, dep);
        for (int j = 0; j < thick; j++) {
            int xx = x - thick / 2 + j;
            if ((unsigned)xx >= (unsigned)W || y >= s_bottom[xx]) continue;
            int i = y * W + xx;
            if (zb[i] <= zc) continue;
            fb[i] = fogged(col, dep, xx, y); zb[i] = zc;
        }
    }
}
static inline bool roughlyInView(float x, float z, float maxD) {
    float dx = x - cx, dz = z - cz, d = dx * fx + dz * fz, l = dx * rx + dz * rz;
    return d > -12.f && d < maxD && fabsf(l) < fmaxf(d, 0.f) * 1.1f + 20.f;
}
static inline int timberShade(float nx, float nz) {  // a vertical timber face lit by the sun (the deck's top: flat light)
    float lt = 0.22f + 0.62f * fmaxf(0.f, nx * s_sunDx + nz * s_sunDz) * s_sunK;
    return clampi((int)(lt * 8.f) - 1, 0, 5);
}
static void drawDeckSeg(const RoadNode& a, const RoadNode& b, bool river) {
    if (!roughlyInView(a.x, a.z, 320.f) && !roughlyInView(b.x, b.z, 320.f)) return;
    const float ha = a.half20 * 0.05f + 1.3f, hb = b.half20 * 0.05f + 1.3f;   // the road and its shoulders: what the wheels ride
    const float pax = -sinf(a.yaw), paz = cosf(a.yaw), pbx = -sinf(b.yaw), pbz = cosf(b.yaw);
    const float ya = a.y + 0.13f, yb = b.y + 0.13f;                  // just above the road's crown at the abutments
    CV top[4] = { camPt(a.x + pax * ha, ya, a.z + paz * ha, a.s), camPt(b.x + pbx * hb, yb, b.z + pbz * hb, b.s),
                  camPt(b.x - pbx * hb, yb, b.z - pbz * hb, b.s), camPt(a.x - pax * ha, ya, a.z - paz * ha, a.s) };
    if (river) fillPoly(top, 4, 3, clampi((int)(s_light[0x88] * 12.f), 2, 12));      // a river bridge: a concrete deck
    else fillPoly(top, 4, 0, clampi((int)(s_light[0x88] * 8.f), 1, 6));
    for (int e = -1; e <= 1; e += 2) {                 // the stringer along each side, and the rail
        float qax = a.x + pax * ha * e, qaz = a.z + paz * ha * e, qbx = b.x + pbx * hb * e, qbz = b.z + pbz * hb * e;
        CV side[4] = { camPt(qax, ya, qaz, 0.f), camPt(qbx, yb, qbz, 0.f), camPt(qbx, yb - 0.7f, qbz, 0.f), camPt(qax, ya - 0.7f, qaz, 0.f) };
        int sh = timberShade(pax * e, paz * e);
        if (river) { fillPoly(side, 4, 3, sh * 2 + 2); continue; }      // (its truss is its rail: drawRiverTruss)
        fillPoly(side, 4, 1, sh);
        line3(qax, ya + 0.95f, qaz, qbx, yb + 0.95f, qbz, (uint8_t)(P_BARK + clampi(sh + 2, 0, 7)), 1);
    }
}
static void drawBent(const RoadNode& n, bool river) {  // the trestle's legs at this node, braced when tall (a river bridge: concrete piers)
    if (!roughlyInView(n.x, n.z, 260.f)) return;
    const float hf = n.half20 * 0.05f;
    const float px = -sinf(n.yaw), pz = cosf(n.yaw);
    const float top = n.y + 0.05f - 0.7f;
    float lx[2], lz[2], gy[2];
    for (int e = 0; e < 2; e++) {
        float o = (e ? -1.f : 1.f) * (hf + 0.9f);                   // under the deck's edges
        lx[e] = n.x + px * o; lz[e] = n.z + pz * o;
        Ground g; terrainGround(lx[e], lz[e], g);
        // a foot on the driving surface of a road below: this bent would stand in its lane. The span carries over
        // it instead (no legs here; the bents either side of the road stay). The deck's own road is 0.9 m clear.
        if (g.mat != MAT_WATER && fabsf(g.across) < g.half + 0.3f) return;
        gy[e] = g.mat == MAT_WATER ? g.h + g.water : g.h;   // the land, or the road under the deck
    }
    float tall = top - fminf(gy[0], gy[1]);
    if (tall < 0.4f) return;
    float d = (n.x - cx) * fx + (n.z - cz) * fz;
    if (river) {                                       // a pier every 15 m: two round columns and a cap beam
        if (((int)floorf(n.s / ROAD_DS + 0.5f)) % 5) return;
        int tp = clampi((int)(1.1f * F / fmaxf(d, 1.f)), 1, 14);
        int sh = timberShade(px, pz);
        uint8_t c = (uint8_t)(P_ROAD + clampi(sh * 2 + 3, 0, 15)), c2 = (uint8_t)(P_ROAD + clampi(sh * 2 + 1, 0, 15));
        for (int e = 0; e < 2; e++) if (top - gy[e] > 0.3f) line3(lx[e], top, lz[e], lx[e], gy[e] - 0.5f, lz[e], e ? c2 : c, tp);
        line3(lx[0], top - 0.2f, lz[0], lx[1], top - 0.2f, lz[1], c2, clampi(tp / 2, 1, 6));
        return;
    }
    int thick = clampi((int)(0.28f * F / fmaxf(d, 1.f)), 1, 5);
    int sh = timberShade(px, pz);
    uint8_t c = (uint8_t)(P_BARK + sh), c2 = (uint8_t)(P_BARK + clampi(sh - 1, 0, 7));
    for (int e = 0; e < 2; e++) if (top - gy[e] > 0.3f) line3(lx[e], top, lz[e], lx[e], gy[e] - 0.2f, lz[e], c, thick);
    if (tall > 2.5f) {                                 // a cross-tie and an X brace
        float low = fmaxf(gy[0], gy[1]) + 0.3f;
        line3(lx[0], top - 0.3f, lz[0], lx[1], top - 0.3f, lz[1], c2, 1);
        line3(lx[0], top - 0.3f, lz[0], lx[1], low, lz[1], c2, 1);
        line3(lx[1], top - 0.3f, lz[1], lx[0], low, lz[0], c2, 1);
    }
}
static inline void putFog(int x, int y, uint8_t c, uint8_t zc, float dep) {
    if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
    int i = y * W + x;
    if (zb[i] <= zc) return;
    fb[i] = fogged(c, dep, x, y); zb[i] = zc;
}
// the yellow caution triangle, point up on a post, black outline; retroreflective: it lights up in the headlights
static void drawCaution(const RoadNode& n, int side) {
    const float hf = n.half20 * 0.05f;
    float wx = n.x - sinf(n.yaw) * side * (hf + 2.2f), wz = n.z + cosf(n.yaw) * side * (hf + 2.2f);
    if (!roughlyInView(wx, wz, 165.f)) return;
    float gy = terrainHeight(wx, wz);
    float sx, sy, d;
    if (!renderProject(wx, gy, wz, sx, sy, d) || d > 160.f || d < 1.f) return;
    float pw = 1.6f * F / d, post = 1.8f * F / d, th = pw * 0.87f;   // 1.6 m: readable at this resolution
    uint8_t zc = zcode(d);
    float hk = headAt((wx - cx) * rx + (wz - cz) * rz, d);
    uint8_t fill = (uint8_t)(P_LINE_Y + (hk > 0.25f ? 3 : 2));
    int xs = ifloor(sx);
    int postW = pw > 12.f ? 2 : 1;
    for (int y = ifloor(sy - post); y < ifloor(sy); y++) for (int k = 0; k < postW; k++) putFog(xs + k, y, P_BLACK, zc, d);
    if (pw < 2.5f) { putFog(xs, ifloor(sy - post) - 1, fill, zc, d); return; }
    float y1 = sy - post, y0 = y1 - th;
    int ot = pw > 16.f ? 2 : 1;
    int r0 = iceil(y0), r1 = ifloor(y1);
    float ih = 1.f / (y1 - y0);
    for (int y = r0; y <= r1; y++) {
        float hw = (y - y0) * ih * pw * 0.5f;
        int xl = ifloor(sx - hw), xr = ifloor(sx + hw);
        for (int x = xl; x <= xr; x++) {
            bool edge = x < xl + ot || x > xr - ot || y > r1 - ot || y < r0 + ot;
            putFog(x, y, edge ? (uint8_t)P_BLACK : fill, zc, d);
        }
    }
}
// ---- a river bridge's through truss (steel, both sides): chords, posts, diagonals and the struts overhead
static void drawRiverTruss(const RoadNode& a, const RoadNode& b, bool aEnd, bool bEnd, int k) {
    if (!roughlyInView(a.x, a.z, 300.f) && !roughlyInView(b.x, b.z, 300.f)) return;
    const float ha = a.half20 * 0.05f + 1.5f, hb = b.half20 * 0.05f + 1.5f, TH = 5.5f;
    const float pax = -sinf(a.yaw), paz = cosf(a.yaw), pbx = -sinf(b.yaw), pbz = cosf(b.yaw);
    const float d = fmaxf(1.f, (a.x - cx) * fx + (a.z - cz) * fz);
    const int th = clampi((int)(0.35f * F / d), 1, 4);
    const int sh = clampi((int)(s_light[0x88] * 12.f), 3, 13);
    const uint8_t c = (uint8_t)(P_ROAD + sh), c2 = (uint8_t)(P_ROAD + clampi(sh - 2, 0, 15));
    for (int e = -1; e <= 1; e += 2) {
        const float ax = a.x + pax * ha * e, az = a.z + paz * ha * e, bx = b.x + pbx * hb * e, bz = b.z + pbz * hb * e;
        const float ya = a.y + 0.2f, yb = b.y + 0.2f;
        const float ta = aEnd ? ya : ya + TH, tb = bEnd ? yb : yb + TH;      // the ends slope down to the deck
        line3(ax, ya, az, bx, yb, bz, c2, th);                               // bottom chord
        line3(ax, ta, az, bx, tb, bz, c, th);                                // top chord (an end post where it slopes)
        if (!aEnd) line3(ax, ya, az, ax, ta, az, c, th);                    // post
        if (!aEnd && !bEnd) {                                                // diagonals, alternating
            if (k & 1) line3(ax, ya, az, bx, tb, bz, c2, clampi(th - 1, 1, 3));
            else line3(ax, ta, az, bx, yb, bz, c2, clampi(th - 1, 1, 3));
        }
    }
    if (!aEnd) line3(a.x + pax * ha, a.y + 0.2f + TH, a.z + paz * ha, a.x - pax * ha, a.y + 0.2f + TH, a.z - paz * ha, c2, clampi(th - 1, 1, 3));   // strut overhead
}
// ---- tunnels: a concrete tube along the road where it runs through a ridge (RN_TUNNEL), lamps along its roof, and a
// rock headwall round each portal. The road inside is kept out of the sun (terrain: its cells' shadow bit).
static void drawTunnelSeg(const RoadNode& a, const RoadNode& b, int k) {
    if (!roughlyInView(a.x, a.z, 280.f) && !roughlyInView(b.x, b.z, 280.f)) return;
    const float ha = a.half20 * 0.05f + 1.6f, hb = b.half20 * 0.05f + 1.6f, WH = 4.6f, RH = 6.6f;
    const float pax = -sinf(a.yaw), paz = cosf(a.yaw), pbx = -sinf(b.yaw), pbz = cosf(b.yaw);
    auto P = [&](const RoadNode& n, float px, float pz, float hf, float acr, float up) { return camPt(n.x + px * hf * acr, n.y + up, n.z + pz * hf * acr, 0.f); };
    const float lt = s_light[0x88];
    const int wall = clampi((int)(lt * 5.f) + 2, 2, 7), roof = clampi((int)(lt * 3.f) + 1, 1, 5);
    for (int e = -1; e <= 1; e += 2) {
        CV w[4] = { P(a, pax, paz, ha, e, -0.3f), P(b, pbx, pbz, hb, e, -0.3f), P(b, pbx, pbz, hb, e, WH), P(a, pax, paz, ha, e, WH) };
        fillPoly(w, 4, 3, wall + ((k & 1) ? 1 : 0));                      // the walls, in 3 m panels
        CV r[4] = { P(a, pax, paz, ha, e, WH), P(b, pbx, pbz, hb, e, WH), P(b, pbx, pbz, hb, e * 0.55f, RH), P(a, pax, paz, ha, e * 0.55f, RH) };
        fillPoly(r, 4, 3, roof + 1);                                       // the haunches
    }
    CV c[4] = { P(a, pax, paz, ha, -0.55f, RH), P(b, pbx, pbz, hb, -0.55f, RH), P(b, pbx, pbz, hb, 0.55f, RH), P(a, pax, paz, ha, 0.55f, RH) };
    fillPoly(c, 4, 3, roof);                                               // the crown
    if ((k & 3) == 0) line3(a.x, a.y + RH - 0.1f, a.z, b.x * 0.4f + a.x * 0.6f, b.y * 0.4f + a.y * 0.6f + RH - 0.1f, b.z * 0.4f + a.z * 0.6f, P_WINDOW, 2);   // a lamp
}
static void drawPortal(const RoadNode& n, bool backward) {
    if (!roughlyInView(n.x, n.z, 300.f)) return;
    const float hf = n.half20 * 0.05f + 1.6f, RH = 6.6f, WW = hf + 14.f;
    const float px = -sinf(n.yaw), pz = cosf(n.yaw);
    float top = fmaxf(terrainNatural(n.x, n.z) - n.y, RH + 3.f) + 1.f;
    auto P = [&](float acr, float up) { return camPt(n.x + px * acr, n.y + up, n.z + pz * acr, 0.f); };
    const float fxn = cosf(n.yaw) * (backward ? 1.f : -1.f), fzn = sinf(n.yaw) * (backward ? 1.f : -1.f);   // the face's outward normal
    const int sh = clampi((int)((0.35f + 0.65f * fmaxf(0.f, fxn * s_sunDx + fzn * s_sunDz) * s_sunK) * s_light[0x88] * 14.f), 1, 13);
    CV l[4] = { P(-WW, -2.f), P(-hf, -2.f), P(-hf, top), P(-WW, top) };
    CV r[4] = { P(hf, -2.f), P(WW, -2.f), P(WW, top), P(hf, top) };
    CV m[4] = { P(-hf, RH), P(hf, RH), P(hf, top), P(-hf, top) };
    CV ql[3] = { P(-hf, 4.6f), P(-hf * 0.55f, RH), P(-hf, RH) }, qr[3] = { P(hf, 4.6f), P(hf, RH), P(hf * 0.55f, RH) };
    fillPoly(l, 4, 2, sh); fillPoly(r, 4, 2, sh); fillPoly(m, 4, 2, sh);
    fillPoly(ql, 3, 2, sh); fillPoly(qr, 3, 2, sh);
    const uint8_t rim = (uint8_t)(P_ROAD + clampi(sh + 2, 0, 15));        // the concrete ring round the bore
    line3(n.x - px * hf, n.y - 0.3f, n.z - pz * hf, n.x - px * hf, n.y + 4.6f, n.z - pz * hf, rim, 2);
    line3(n.x + px * hf, n.y - 0.3f, n.z + pz * hf, n.x + px * hf, n.y + 4.6f, n.z + pz * hf, rim, 2);
    line3(n.x - px * hf * 0.55f, n.y + RH, n.z - pz * hf * 0.55f, n.x + px * hf * 0.55f, n.y + RH, n.z + pz * hf * 0.55f, rim, 2);
}

static void structuresOn(bool arm, int lo, int hi) {
    const int n = arm ? roadArmCount() : roadCount();
    for (int i = lo; i <= hi; i++) {
        const RoadNode& a = arm ? roadArmNode(i) : roadNode(i);
        if (!(a.flags & (RN_BRIDGE | RN_CAUTION | RN_TUNNEL))) {
            if (i + 1 < n && ((arm ? roadArmNode(i + 1) : roadNode(i + 1)).flags & RN_BRIDGE)) {   // a deck starts next
                const RoadNode& b = arm ? roadArmNode(i + 1) : roadNode(i + 1);
                drawDeckSeg(a, b, (b.side & RN_SIDE_RIVER) != 0);
            }
            continue;
        }
        if (a.flags & RN_CAUTION) {
            if (a.side & RN_SIDE_CAUTION_R) drawCaution(a, 1);
            if (a.side & RN_SIDE_CAUTION_L) drawCaution(a, -1);
        }
        if (a.flags & RN_TUNNEL) {
            const bool pT = i > 0 && ((arm ? roadArmNode(i - 1) : roadNode(i - 1)).flags & RN_TUNNEL);
            const bool nT = i + 1 < n && ((arm ? roadArmNode(i + 1) : roadNode(i + 1)).flags & RN_TUNNEL);
            if (!pT) drawPortal(a, false);
            if (!nT) drawPortal(a, true);
            if (nT) drawTunnelSeg(a, arm ? roadArmNode(i + 1) : roadNode(i + 1), i);
            continue;
        }
        if (!(a.flags & RN_BRIDGE)) {
            // the node before a deck: its approach slab, at the road's height, over the land's step down to the span
            // (the land is baked in 2.5 m cells: between the road's last cell and the first under the deck it slopes away)
            if (i + 1 < n) { const RoadNode& b = arm ? roadArmNode(i + 1) : roadNode(i + 1); if (b.flags & RN_BRIDGE) drawDeckSeg(a, b, (b.side & RN_SIDE_RIVER) != 0); }
            continue;
        }
        const bool river = (a.side & RN_SIDE_RIVER) != 0;
        drawBent(a, river);
        if (i + 1 < n) {
            const RoadNode& b = arm ? roadArmNode(i + 1) : roadNode(i + 1);
            if (!(b.flags & RN_BRIDGE)) drawDeckSeg(a, b, river);         // and the slab off its far end
            else {
                drawDeckSeg(a, b, river);
                if (river) {
                    const bool aEnd = i == 0 || !((arm ? roadArmNode(i - 1) : roadNode(i - 1)).flags & RN_BRIDGE);
                    const bool bEnd = i + 2 >= n || !((arm ? roadArmNode(i + 2) : roadNode(i + 2)).flags & RN_BRIDGE);
                    drawRiverTruss(a, b, aEnd, bEnd, i);
                }
            }
        }
    }
}
// ---- the Red Canyon's arches (field.cpp places them): a rough red rock ring over the road, 4 m thick, its legs set
// 4.5 m past the road's edges and sunk into the ground
static void drawArches() {
    int n; const Arch* A = fieldArches(n);
    for (int k = 0; k < n; k++) {
        const Arch& a = A[k];
        if (!roughlyInView(a.x, a.z, 340.f)) continue;
        const float fx2 = a.az, fz2 = -a.ax;                         // along the road
        const float hi = 8.5f + a.ri * 0.15f, ho = hi + 3.2f;
        const float lowL = fminf(a.y - 1.5f, terrainHeight(a.x - a.ax * (a.ri + 1.7f), a.z - a.az * (a.ri + 1.7f)) - 0.6f);
        const float lowR = fminf(a.y - 1.5f, terrainHeight(a.x + a.ax * (a.ri + 1.7f), a.z + a.az * (a.ri + 1.7f)) - 0.6f);
        const uint32_t sd = hash32((uint32_t)(a.x * 7.f) ^ (uint32_t)(a.z * 13.f));
        const int K = 10;
        float pa[K + 1], pu[K + 1], qa[K + 1], qu[K + 1];              // inner and outer rings: across, up
        for (int i = 0; i <= K; i++) {
            float th = 3.1415927f * i / K, c = -cosf(th), s = sinf(th);
            float jag = (i == 0 || i == K) ? 0.f : (hashf(sd + i * 7) - 0.5f) * 1.1f;
            pa[i] = a.ri * c; pu[i] = a.y - 0.3f + hi * s;
            qa[i] = (a.ro + jag) * c; qu[i] = a.y - 0.3f + ho * s + jag;
            if (i == 0) { pu[i] = qu[i] = lowL; } else if (i == K) { pu[i] = qu[i] = lowR; }
        }
        const float lt = s_light[0x88];
        const int front = clampi((int)((0.35f + 0.65f * fmaxf(0.f, -(fx2 * s_sunDx + fz2 * s_sunDz)) * s_sunK) * lt * 15.f), 1, 14);
        const int back = clampi((int)((0.35f + 0.65f * fmaxf(0.f, fx2 * s_sunDx + fz2 * s_sunDz) * s_sunK) * lt * 15.f), 1, 14);
        auto P = [&](float acr, float up, float al) { return camPt(a.x + a.ax * acr + fx2 * al, up, a.z + a.az * acr + fz2 * al, 0.f); };
        for (int i = 0; i < K; i++) {
            const float T = 2.f;
            CV f[4] = { P(qa[i], qu[i], -T), P(qa[i + 1], qu[i + 1], -T), P(pa[i + 1], pu[i + 1], -T), P(pa[i], pu[i], -T) };
            CV b[4] = { P(qa[i], qu[i], T), P(qa[i + 1], qu[i + 1], T), P(pa[i + 1], pu[i + 1], T), P(pa[i], pu[i], T) };
            CV o[4] = { P(qa[i], qu[i], -T), P(qa[i + 1], qu[i + 1], -T), P(qa[i + 1], qu[i + 1], T), P(qa[i], qu[i], T) };
            CV u[4] = { P(pa[i], pu[i], -T), P(pa[i + 1], pu[i + 1], -T), P(pa[i + 1], pu[i + 1], T), P(pa[i], pu[i], T) };
            float mid = (i + 0.5f) / K;                               // the top catches the sky; the underside is in shade
            fillPoly(o, 4, 2, clampi((int)(lt * (8.f + 5.f * sinf(3.1415927f * mid))), 1, 14));
            fillPoly(u, 4, 2, clampi((int)(lt * 4.f), 1, 8));
            fillPoly(f, 4, 2, front);
            fillPoly(b, 4, 2, back);
        }
    }
}

// ---- geysers (field.cpp): a pale sinter pad, and when one blows, a column of white water up to 20 m; between
// eruptions a little steam
static void drawGeysers() {
    int n; const Geyser* G = fieldGeysers(n);
    const float tt = g_scene.t;
    for (int k = 0; k < n; k++) {
        const Geyser& g = G[k];
        if (!roughlyInView(g.x, g.z, 280.f)) continue;
        CV pad[8];
        for (int i = 0; i < 8; i++) {
            float an = i * 0.785398f;
            pad[i] = camPt(g.x + cosf(an) * 4.f, g.y + 0.08f, g.z + sinf(an) * 3.f, 0.f);
        }
        fillPoly(pad, 8, 2, clampi((int)(s_light[0x88] * 15.f), 2, 15));
        float sx, sy, d;
        if (!renderProject(g.x, g.y, g.z, sx, sy, d) || d < 1.f) continue;
        const float H0 = g.h > 0.5f ? g.h : 1.5f + 0.5f * sinf(tt * 1.3f + g.x);   // the column, or the steam
        const float top = sy - H0 * F / d;
        const uint8_t zc = zcode(fmaxf(d - 1.f, 0.6f));
        int y0 = (int)top, y1 = (int)sy;
        if (y0 < 0) y0 = 0;
        if (y1 > H) y1 = H;
        g_fallsNear = fmaxf(g_fallsNear, g.h > 3.f ? clampf(1.f - d * (1.f / 160.f), 0.f, 1.f) : 0.f);
        for (int y = y0; y < y1; y++) {
            float v = (sy - y) / (sy - top + 0.5f);                    // 0 at the ground, 1 at the top
            float hw = (g.h > 0.5f ? 1.1f + 2.6f * v * v + (v > 0.82f ? (v - 0.82f) * 14.f : 0.f) : 0.6f + 1.2f * v) * F / d;   // a plume, billowing at the top
            int xa = (int)(sx - hw), xb = (int)(sx + hw);
            if (xa < 0) xa = 0;
            if (xb > W - 1) xb = W - 1;
            for (int x = xa; x <= xb; x++) {
                int i2 = y * W + x;
                if (y >= s_bottom[x] || zb[i2] <= zc) continue;
                uint32_t hh = hash32((uint32_t)((x - (int)sx) / 2 + 64) * 0x9E3779B1u ^ (uint32_t)((y + (int)(tt * 30.f)) / 2) * 0x85EBCA77u);
                if (g.h <= 0.5f && (hh & 3) != 0) continue;              // steam: thin, broken
                float ux = fabsf((x - sx) / (hw + 0.5f));
                if (ux > 0.7f && (hh & 1)) continue;                     // a ragged edge
                int lv = 4 + (int)((hh >> 4) & 3) - (ux > 0.6f ? 1 : 0);
                fb[i2] = fogged((uint8_t)(P_SNOW + clampi(lv, 0, 7)), d, x, y); zb[i2] = zc;
            }
        }
    }
}

// ---- launch ramps (terrain.cpp shapes the land): a timber frame along the kicker's sides and at its lip
static void drawRamps() {
    const float R = 120.f;
    const int i0 = (int)floorf((cx - R) / RAMP_LATTICE), i1 = (int)floorf((cx + R) / RAMP_LATTICE);
    const int j0 = (int)floorf((cz - R) / RAMP_LATTICE), j1 = (int)floorf((cz + R) / RAMP_LATTICE);
    for (int lj = j0; lj <= j1; lj++) for (int li = i0; li <= i1; li++) {
        Ramp r;
        if (!terrainRamp(li, lj, r, false) || !roughlyInView(r.x, r.z, R) || sq(r.x - cx) + sq(r.z - cz) > R * R) continue;
        if (!terrainRamp(li, lj, r, true)) continue;
        const float sxn = -r.uz, szn = r.ux;                            // across the ramp
        const float d = sqrtf(sq(r.x - cx) + sq(r.z - cz));
        const int th = d < 20.f ? 2 : 1;
        const uint8_t c = (uint8_t)(P_BARK + clampi((int)(s_light[0x88] * 6.f), 1, 5)), c2 = (uint8_t)(P_BARK + clampi((int)(s_light[0x88] * 6.f) + 1, 1, 6));
        // the kicker's timber deck, true to its shape (the land's cells round its lip off): the run-up's foot on the
        // ground, the lip 3 m over the ground under it (that ground: between the foot and just past the drop)
        const float sx0 = r.x - r.ux * 11.f, sz0 = r.z - r.uz * 11.f, yFoot = terrainHeight(sx0, sz0);
        const float yPast = terrainHeight(r.x + r.ux * 3.f, r.z + r.uz * 3.f);
        const float yLip = yFoot + (yPast - yFoot) * (11.f / 14.f) + 3.f, yLipG = yLip - 3.f;
        CV dk[4] = { camPt(sx0 - sxn * 2.4f, yFoot + 0.05f, sz0 - szn * 2.4f, 0.f), camPt(r.x - sxn * 2.4f, yLip, r.z - szn * 2.4f, 11.f),
                     camPt(r.x + sxn * 2.4f, yLip, r.z + szn * 2.4f, 11.f), camPt(sx0 + sxn * 2.4f, yFoot + 0.05f, sz0 + szn * 2.4f, 0.f) };
        fillPoly(dk, 4, 0, clampi((int)(s_light[0x88] * 8.f), 1, 6));
        for (int e = -1; e <= 1; e += 2) {
            const float ox = sxn * 2.45f * e, oz = szn * 2.45f * e;
            CV sd[3] = { camPt(sx0 + ox, yFoot, sz0 + oz, 0.f), camPt(r.x + ox, yLip, r.z + oz, 0.f), camPt(r.x + ox, yLipG - 0.3f, r.z + oz, 0.f) };
            fillPoly(sd, 3, 1, timberShade(sxn * e, szn * e));                      // its sides, down to the ground
            line3(sx0 + ox, yFoot + 0.1f, sz0 + oz, r.x + ox, yLip + 0.1f, r.z + oz, c2, th);   // the edge rail
            line3(r.x + ox, yLip, r.z + oz, r.x + ox, yLipG - 0.3f, r.z + oz, c, th);           // the post at the lip
        }
        line3(r.x - sxn * 2.45f, yLip + 0.1f, r.z - szn * 2.45f, r.x + sxn * 2.45f, yLip + 0.1f, r.z + szn * 2.45f, c2, th);   // the lip
    }
}

extern float g_riverNear;                            // the river's sound level (audio)
static void drawRoadStructures() {
    g_riverNear = clampf(1.f - terrainRiverDist(cx, cz) * (1.f / 160.f), 0.f, 1.f);
    int n = roadCount();
    if (n > 1) {
        int c = roadCarIndex();
        int lo = c - 40 < 0 ? 0 : c - 40, hi = c + 140 > n - 1 ? n - 1 : c + 140;
        structuresOn(false, lo, hi);
    }
    if (roadArmMarked()) structuresOn(true, 0, roadArmCount() - 1);
}

static void drawCritters() {
    const Critter* c = fieldCritters();
    for (int k = 0; k < CRIT_N; k++) {
        if (!c[k].on) continue;
        float sx, sy, d;
        if (!renderProject(c[k].x, c[k].y, c[k].z, sx, sy, d) || d > 160.f) continue;
        float dirScreen = sinf(c[k].yaw - cyaw);
        const bool big = c[k].kind == 1;                                    // Bigfoot: 2.4 m tall
        const uint8_t id = big ? (uint8_t)(T_BIGFOOT0 + c[k].pose % 3) : (uint8_t)(T_DEER0 + (c[k].pose & 3));
        blitTpl(id, sx, sy + 1.f, (big ? 2.4f : 1.5f) * F / d, d, dirScreen < 0.f, false, headAt((c[k].x - cx) * rx + (c[k].z - cz) * rz, d));
    }
}

static void drawParticles() {
    const Particle* p = fieldParticles();
    for (int k = 0; k < PART_N; k++) {
        if (p[k].life <= 0.f) continue;
        float sx, sy, d;
        if (!renderProject(p[k].x, p[k].y, p[k].z, sx, sy, d) || d < 0.8f) continue;
        float r = p[k].size * F / d;
        float fade = 1.f - p[k].age / p[k].life;
        uint8_t zc = zcode(d);
        uint8_t c;
        switch (p[k].kind) {
            case PK_MUD: c = P_MUD; break;
            case PK_FUR: c = (uint8_t)(P_BARK + 5 + (k & 1)); break;
            case PK_MIST: c = (uint8_t)(P_FLOWER + 3); break;
            case PK_SPRAY: c = P_HAZE + 12; break;
            case PK_SNOW: c = P_SNOW + 6; break;
            case PK_SMOKE: c = P_HAZE + 13; break;
            default: c = (uint8_t)(P_SOIL + 10); break;
        }
        bool puff = p[k].kind == PK_DUST || p[k].kind == PK_SMOKE || p[k].kind == PK_MIST;
        // puffs thin out as they grow and age, and near the lens they are mostly air
        float dens = puff ? fade * 0.45f * clampf(d / 6.f, 0.15f, 1.f) : 1.f;
        int R = (int)(r + 0.5f);
        int cap = puff ? 7 : 2;
        if (R > cap) R = cap;
        if (!puff && d < 2.5f) continue;
        for (int dy = -R; dy <= R; dy++) for (int dx = -R; dx <= R; dx++) {
            if (dx * dx + dy * dy > R * R + 1) continue;
            int x = (int)sx + dx, y = (int)sy + dy;
            if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) continue;
            if (dens < 1.f && dith(x + k, y) > dens * (1.f - (dx * dx + dy * dy) / (float)(R * R + 1) * 0.6f)) continue;
            putZ(x, y, c, zc);
        }
    }
}

// ================================================================================== reflections, weather
MR_HOT static void reflectPass() {
    const float t = s_t;
    for (int x = 0; x < W; x++) {
        for (int y = (int)horX[x] + 1; y < H; y++) {
            if (y < 0) continue;
            int i = y * W + x;
            if (!(zb[i] & 1)) continue;
            uint8_t cur = fb[i];
            bool water = cur >= P_WATER && cur < P_WATER + 8;
            int ym = (int)(2.f * horX[x] - y + 1.f);
            int xs = x + (((y + (int)(t * 6.f)) & 7) < 2 ? 1 : 0);
            if (xs >= W) xs = W - 1;
            uint8_t src = ym >= 0 ? fb[ym * W + xs] : (uint8_t)P_SKY;
            uint8_t r = s_refl[src];
            float fres = clampf(1.f - (y - horX[x]) / 55.f, 0.25f, 1.f);
            // lakes keep the screen dither they were approved with; only wet road and mud use the surface's own grain
            float gp = (water || !s_gpat) ? dith(x, y) : s_gpat[i] * (1.f / 255.f);
            if (water) fb[i] = (fres > gp) ? r : cur;
            else if (s_wet * 0.55f * fres > gp) fb[i] = r;
        }
    }
}

// The sun's glint: a column of sparkles on the water (and wet road) under the sun, widening toward you; it twinkles
// 12 times a second whatever the frame rate. A narrow band once a frame: flash.
__attribute__((noinline)) static void drawGlint() {
    if (!(s_sunVis > 0.f && g_scene.sunElev > -0.02f && s_sunX > -13.f && s_sunX < W + 13.f)) return;
    const float k0 = s_sunVis * (0.45f + 0.55f * s_lowSun) * 0.55f;
    const uint32_t tw = (uint32_t)(s_t * 12.f) * 0x9E3779B1u;
    const int xa = clampi((int)floorf(s_sunX - 13.f), 0, W), xb = clampi((int)ceilf(s_sunX + 13.f), 0, W);
    for (int x = xa; x < xb; x++) {
        const float dx = fabsf(x - s_sunX);
        for (int y = clampi((int)horX[x] + 1, 0, H); y < H; y++) {
            const int i = y * W + x;
            if (!(zb[i] & 1)) continue;
            const float gw = 0.8f + (y - horX[x]) * 0.1f;
            if (dx >= gw) continue;
            uint32_t h = ((uint32_t)i * 0x85EBCA6Bu) ^ tw; h ^= h >> 13; h *= 0xC2B2AE35u; h ^= h >> 16;
            if ((h & 1023u) * (1.f / 1024.f) < k0 * (1.f - dx / gw)) fb[i] = (uint8_t)(P_SUN + 6 + (h >> 10 & 1));
        }
    }
}

static void drawRain() {
    const Scene& sc = g_scene;
    float amt = sc.rain;
    if (amt < 0.05f) return;
    int n = (int)(amt * 70.f);
    float slant = clampf(-sc.speed * 0.012f + sinf(sc.windAz - cyaw) * sc.wind * 0.6f, -1.2f, 1.2f);
    uint32_t seed = (uint32_t)(s_t * 30.f) * 2654435761u;
    for (int k = 0; k < n; k++) {
        uint32_t h = hash32(seed + k * 7919u);
        int x = h % W, y = (h >> 9) % H;
        int len = 3 + ((h >> 17) & 3);
        for (int j = 0; j < len; j++) {
            int xx = x + (int)(j * slant * 0.5f), yy = y + j;
            if ((unsigned)xx < (unsigned)W && (unsigned)yy < (unsigned)H) fb[yy * W + xx] = s_bright[fb[yy * W + xx]] == fb[yy * W + xx] ? (uint8_t)(P_HAZE + 13) : s_bright[s_bright[fb[yy * W + xx]]];
        }
    }
}

struct Flake { float x, y, z; };
static Flake s_flk[60];
static void drawSnow() {
    const Scene& sc = g_scene;
    if (sc.snow < 0.05f) return;
    int n = (int)(sc.snow * 60.f);
    float dt = sc.dt;
    for (int k = 0; k < n; k++) {
        Flake& f = s_flk[k];
        f.z -= sc.speed * dt;
        f.y -= 1.2f * dt;
        f.x += sinf(s_t * 0.7f + k) * 0.4f * dt + sc.wind * dt;
        if (f.z < 0.6f || f.y < -2.f) {
            uint32_t h = hash32((uint32_t)k * 31u + (uint32_t)(s_t * 10.f));
            f.z = 2.f + (h & 255) / 255.f * 18.f; f.x = ((h >> 8 & 255) / 255.f - 0.5f) * f.z * 1.6f; f.y = ((h >> 16 & 255) / 255.f) * 6.f - 1.f;
        }
        int x = (int)(W * 0.5f + f.x / f.z * F), y = (int)(hor0 - f.y / f.z * F);
        if ((unsigned)x < (unsigned)W && (unsigned)y < (unsigned)H) {
            fb[y * W + x] = P_SNOW + 7;
            if (f.z < 4.f && x + 1 < W) fb[y * W + x + 1] = P_SNOW + 6;
        }
    }
}

static void drawFireflies() {
    const Scene& sc = g_scene;
    if (sc.fireflies < 0.05f) return;
    int n = (int)(sc.fireflies * 26.f);
    for (int k = 0; k < n; k++) {
        uint32_t h = hash32((uint32_t)k * 7u + worldSeed());
        float ph = s_t * (0.2f + (h & 15) * 0.02f) + k;
        float wx = cx + ((h & 255) / 255.f - 0.5f) * 50.f + sinf(ph) * 2.f;
        float wz = cz + ((h >> 8 & 255) / 255.f - 0.5f) * 50.f + cosf(ph * 0.7f) * 2.f;
        float blink = sinf(s_t * (1.f + (h >> 16 & 7) * 0.3f) + k * 2.f);
        if (blink < 0.3f) continue;
        float sx, sy, d;
        float gy = terrainHeight(wx, wz) + 0.6f + sinf(ph * 1.3f) * 0.4f;
        if (!renderProject(wx, gy, wz, sx, sy, d) || d > 40.f) continue;
        putZ((int)sx, (int)sy, P_FIREFLY, zcode(d));
        if (d < 10.f) { putZ((int)sx + 1, (int)sy, P_FIREFLY, zcode(d)); }
    }
}

static void drawLeaves() {
    const Scene& sc = g_scene;
    if (sc.leaves < 0.05f) return;
    int n = (int)(sc.leaves * 14.f);
    for (int k = 0; k < n; k++) {
        uint32_t h = hash32((uint32_t)k * 13u + 99u);
        float sp = 18.f + (h & 31);
        float x = fmodf((h >> 5 & 255) * 0.7f + s_t * (sc.wind * 30.f + 6.f) + sinf(s_t * 2.f + k) * 6.f, (float)W + 20.f) - 10.f;
        float y = fmodf((h >> 13 & 255) * 0.5f + s_t * sp, (float)H + 10.f) - 5.f;
        uint8_t c = (h & 1) ? (uint8_t)(P_LEAF2 + 5) : (uint8_t)(P_LEAF + 12);
        int xi = (int)x, yi = (int)y;
        if ((unsigned)xi < (unsigned)W && (unsigned)yi < (unsigned)H) { fb[yi * W + xi] = c; if (((int)(s_t * 6.f + k) & 1) && xi + 1 < W) fb[yi * W + xi + 1] = c; }
    }
}

static void drawBolt() {
    const Scene& sc = g_scene;
    if (sc.boltAge > 0.3f) return;
    float rel = wrapPi(sc.boltAz - cyaw);
    if (fabsf(rel) > 0.9f) return;
    float x = W * 0.5f + tanf(rel) * F;
    uint32_t h = sc.boltSeed;
    int y0 = 0, y1 = (int)horX[clampi((int)x, 0, W - 1)];
    if (y1 > H) y1 = H;                                  // the horizon below the picture: never past the frame
    for (int y = y0; y < y1; y++) {
        h = hash32(h + (uint32_t)y);
        if ((y & 3) == 0) x += ((h & 255) / 255.f - 0.5f) * 5.f;
        int xi = (int)x;
        if ((unsigned)xi >= (unsigned)W) continue;
        int i = y * W + xi;
        if (zb[i] < 254) continue;
        fb[i] = P_BOLT;
        if (xi + 1 < W && zb[i + 1] >= 254) fb[i + 1] = P_SUN + 6;
    }
}

static void drawMist() {
    float mist = S.mist * 0.4f + g_scene.mist + g_scene.fog * 0.35f;
    if (mist < 0.04f) return;
    float rowK[28];                                          // 1 - |y - hy - 3| / 15 for the band's 28 rows
    for (int r = 0; r < 28; r++) rowK[r] = 1.f - fabsf((float)(r - 13)) / 15.f;
    for (int x = 0; x < W; x++) {
        int hy = (int)horX[x];
        for (int y = hy - 10; y < hy + 18; y++) {
            if (y < 0 || y >= H) continue;
            int i = y * W + x;
            if (zb[i] <= 60) continue;
            float k = mist * rowK[y - (hy - 10)] * (0.7f + 0.3f * tex((int)((x + cyaw * F) * 0.1f), (int)(y * 0.4f + s_t * 0.3f)) * (1.f / 255.f));
            float gp = s_gpat ? s_gpat[i] * (1.f / 255.f) : (((x ^ y) & 1) ? 0.f : 1.f);   // the grain of the land under the mist
            float ma = clampf((k - 0.12f) * 2.2f, 0.f, 1.f);         // mist: the land under it steps to its fogged twins
            if (ma > 0.f) fb[i] = fogTwin(fb[i], ma, gp);
        }
    }
}

static uint8_t* s_shaft = nullptr;            // 80x60 brighten chance, refreshed every other frame
static float s_shaftSX = 0.f, s_shaftSY = 0.f;   // where the sun was when it was made
static int s_frameN = 0;
static void drawShafts() {
    const Scene& sc = g_scene;
    if (sc.beams < 0.12f || s_night > 0.6f || s_sunX < -400.f || s_sunX > W + 400.f) return;
    if (!s_shaft) { s_shaft = (uint8_t*)memFast(80 * 60); if (!s_shaft) return; memset(s_shaft, 0, 80 * 60); }
    if (!(s_frameN & 1)) {
        s_shaftSX = s_sunX; s_shaftSY = s_sunY;
        float str = sc.beams * 0.45f;
        for (int y = 0; y < H; y += 2) for (int x = 0; x < W; x += 2) {
            float dx = x - s_sunX, dy = y - s_sunY;
            uint8_t k8 = 0;
            if (dy >= -6.f) {
                float st = tex((int)(fastAtan2(dy, dx) * 20.f + 64.f), (int)(s_t * 0.3f)) * (1.f / 255.f);
                if (st >= 0.56f) {
                    float dist = sqrtf(dx * dx + dy * dy);
                    float k = (st - 0.56f) * 2.3f * str * clampf(1.f - dist / 260.f, 0.f, 1.f);
                    k8 = (uint8_t)clampi((int)(k * 255.f), 0, 255);
                }
            }
            s_shaft[(y >> 1) * 80 + (x >> 1)] = k8;
        }
    }
    int ox = (int)lroundf(s_sunX - s_shaftSX), oy = (int)lroundf(s_sunY - s_shaftSY);   // the shafts move with the sun
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        int mx = (x - ox) >> 1, my = (y - oy) >> 1;
        if ((unsigned)mx >= 80u || (unsigned)my >= 60u) continue;
        uint8_t k8 = s_shaft[my * 80 + mx];
        if (k8 && k8 * (1.f / 255.f) > dith(x, y)) { int i = y * W + x; fb[i] = s_bright[fb[i]]; }
    }
}

static void drawBirds() {
    const Bird* b = fieldBirds();
    if (!b->on) return;
    for (int k = 0; k < b->n; k++) {
        float az = b->az + (k - b->n / 2) * 0.018f - abs(k - b->n / 2) * 0.0f;
        float el = b->el - abs(k - b->n / 2) * 0.012f;
        float rel = wrapPi(az - cyaw);
        if (fabsf(rel) > 1.f) continue;
        int x = (int)(W * 0.5f + tanf(rel) * F), y = (int)(hor0 - tanf(el) * F);
        bool flap = ((int)(s_t * 6.f + k) & 1);
        uint8_t c = P_CLOUD + 1;
        if ((unsigned)x < (unsigned)(W - 2) && (unsigned)y < (unsigned)(H - 1) && y > 0) {
            fb[y * W + x] = c;
            fb[(flap ? y - 1 : y) * W + x - 1 + (x > 0 ? 0 : 1)] = c; fb[(flap ? y - 1 : y) * W + x + 1] = c;
        }
    }
}

// ================================================================================== the vehicle, the cockpit
static void drawChaseVehicle() {
    const ViewInfo& v = g_view;
    const art::VehArt& a = art::VEH_ART[v.vehicle];
    float sx, sy, d;
    if (!renderProject(v.x, v.groundY, v.z, sx, sy, d)) return;
    float rel = wrapPi(v.yaw - cyaw);
    bool mirror = rel < 0.f;
    float ar = fabsf(rel) * 57.3f;
    int frame;
    if (v.vehicle == V_BIKE) {
        float lean = fabsf(v.lean) * 57.3f;
        frame = clampi((int)(lean / 10.f + 0.5f), 0, 4);
        mirror = v.lean < 0.f;
    } else {
        static const float YAWS[6] = {0, 7, 15, 25, 37, 52};
        int yi = 0; for (int k = 1; k < 6; k++) if (fabsf(ar - YAWS[k]) < fabsf(ar - YAWS[yi])) yi = k;
        int pi = v.pitch > 0.07f ? 1 : (v.pitch < -0.07f ? 2 : 0);
        frame = pi * 6 + yi;
    }
    const uint8_t* px = a.px + (size_t)frame * ((a.w * a.h + 1) / 2);
    int ox = (int)lroundf(sx) - a.ax, oy = (int)lroundf(sy + v.bounce * F / d) - a.ay;
    // its shadow
    float sw = (v.vehicle == V_BIKE ? 0.5f : 1.0f) * F / d * 1.1f;
    for (int y = -2; y <= 1; y++) for (int x = -(int)sw; x <= (int)sw; x++) {
        int xx = (int)sx + x, yy = (int)sy + y;
        if ((unsigned)xx < (unsigned)W && (unsigned)yy < (unsigned)H && ((xx + yy) & 1)) fb[yy * W + xx] = P_BLACK;
    }
    for (int y = 0; y < a.h; y++) for (int x = 0; x < a.w; x++) {
        int k = y * a.w + (mirror ? a.w - 1 - x : x);
        uint8_t p = (k & 1) ? (px[k >> 1] & 15) : (px[k >> 1] >> 4);
        if (!p) continue;
        int X = ox + x, Y = oy + y;
        if ((unsigned)X < (unsigned)W && (unsigned)Y < (unsigned)H) { fb[Y * W + X] = (uint8_t)(P_VEH + p); zb[Y * W + X] = 0; }
    }
    // tail lights burn at night and under braking
    if ((s_night > 0.4f || v.brake) && v.vehicle != V_BIKE) {
        int ty = oy + a.ay - (int)(0.85f * F / d);
        int tx = (int)(0.62f * F / d);
        uint8_t c = v.brake ? P_TAIL : P_TAIL_D;
        for (int s = -1; s <= 1; s += 2) for (int q = 0; q < 3; q++) {
            int X = (int)sx + s * tx + (q - 1) * s, Y = ty;
            if ((unsigned)X < (unsigned)W && (unsigned)Y < (unsigned)H) fb[Y * W + X] = c;
        }
    }
}

static float s_wheelAng = 0.f;
static uint16_t* s_ckRun = nullptr;            // (start, length) pairs of opaque, non-wheel cockpit pixels
static uint8_t* s_ckPix = nullptr;             // their palette indices, ready to copy
static int s_ckRuns = 0;
// lroundf(v) bit for bit (half away from zero), inline: the wheel loop never leaves IRAM for the library's copy in
// flash. Exact for |v| < 2^23: v - (float)(int)v is then exactly v's fractional part.
static inline __attribute__((always_inline)) int roundAway(float v) {
    int i = (int)v;
    float f = v - (float)i;
    if (f >= 0.5f) i++; else if (f <= -0.5f) i--;
    return i;
}
MR_HOT static void drawCockpit() {
    if (!s_cock) return;
    const art::CockArt& c = art::COCK_ART[g_view.vehicle];
    const uint8_t* src = s_ckPix;
    for (int r = 0; r < s_ckRuns; r++) {
        int st = s_ckRun[r * 2], len = s_ckRun[r * 2 + 1];
        memcpy(fb + st, src, len); src += len;
    }
    // the wheel turns with the steering
    if (c.wr > 0) {
        s_wheelAng += (g_view.steer * 1.6f - s_wheelAng) * clampf(g_scene.dt * 12.f, 0.f, 1.f);
        float ca = cosf(s_wheelAng), sa = sinf(s_wheelAng);
        int R = s_wheelR > 0 ? s_wheelR : c.wr + 2;                // the whole reach of the wheel's pixels
        // the dash behind the wheel first: where the turned wheel isn't, the dash shows, never last frame
        const int cxI = (int)s_wcx, cyI = (int)s_wcy;
        for (int y = cyI - R; y <= cyI + R + 1; y++) for (int x = cxI - R; x <= cxI + R + 1; x++)
            if ((unsigned)x < (unsigned)W && (unsigned)y < (unsigned)H && s_wheelMask[y * W + x] && y > s_glassLow[x]) fb[y * W + x] = s_wheelBg;
        for (int y = cyI - R; y <= cyI + R + 1; y++) for (int x = cxI - R; x <= cxI + R + 1; x++) {
            if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) continue;
            // turn it as the round wheel it is (the drawing is an ellipse): stretch to a circle, rotate, squash back
            float dx = (float)x - s_wcx, dy = ((float)y - s_wcy) * s_wheelK;
            int sx = roundAway(s_wcx + dx * ca + dy * sa), sy = roundAway(s_wcy + (-dx * sa + dy * ca) / s_wheelK);
            if ((unsigned)sx >= (unsigned)W || (unsigned)sy >= (unsigned)H) continue;
            int si = sy * W + sx;
            if (s_wheelMask[si]) fb[y * W + x] = (uint8_t)(P_COCK + s_cock[si]);
        }
    }
}

// ---- the glass: mud and drops
struct Splat { float x, y, r, life; uint8_t kind; };
static Splat s_spl[14];
void renderSplat(float strength) {
    for (Splat& s : s_spl) if (s.life <= 0.f) {
        uint32_t h = hash32((uint32_t)(s_t * 1000.f) + (uint32_t)(strength * 99.f));
        bool left = h & 1;
        s.x = left ? (h >> 4) % 40 : W - 1 - (h >> 4) % 40; s.y = 10 + (h >> 12) % 90; s.r = 2.f + strength * 4.f + (h >> 20) % 3;
        s.life = 2.5f + strength * 3.f; s.kind = 0; return;
    }
}
void renderWater(float strength) {
    for (Splat& s : s_spl) if (s.life <= 0.f) {
        uint32_t h = hash32((uint32_t)(s_t * 997.f) + 7u);
        s.x = (float)(h % W); s.y = (float)((h >> 8) % 90); s.r = 1.f + strength * 1.5f; s.life = 1.5f; s.kind = 1; return;
    }
}
// ---- the wipers (cockpit, cars): rain and wet glass, and one slow wipe after a deer
static float s_wipT = -1.f, s_wipLen = 1.f, s_wipPause = 0.f, s_wipAng = 0.f, s_deerWipeIn = -1.f;
static bool s_wipDeer = false, s_wipEvent = false, s_wipEventDeer = false;
static constexpr float WIPE_REST = 0.12f, WIPE_TOP = 2.55f;          // radians: lying right, up to the left pillar
void renderDeerSplat() {
    for (int k = 0; k < 9; k++) for (Splat& s : s_spl) if (s.life <= 0.f) {
        uint32_t h = hash32((uint32_t)(s_t * 1000.f) + k * 977u);
        s.x = W * 0.3f + (h % 64); s.y = 24.f + ((h >> 8) % 44); s.r = 1.f + ((h >> 16) & 1); s.life = 30.f; s.kind = 2; break;
    }
    s_deerWipeIn = 0.9f;                                            // a beat... then the wipe
}
bool renderWipeEvent(bool& deer) { bool e = s_wipEvent; deer = s_wipEventDeer; s_wipEvent = false; return e; }
static float wiperAngle(float t, float len) {                      // up and back, easing at both ends
    float ph = t / len;
    float u = ph < 0.5f ? ph * 2.f : (1.f - ph) * 2.f;
    u = u * u * (3.f - 2.f * u);
    return WIPE_REST + (WIPE_TOP - WIPE_REST) * u;
}
static void drawWipers() {
    const ViewInfo& v = g_view;
    float dt = g_scene.dt;
    if (v.view != VIEW_COCKPIT || v.vehicle == V_BIKE) { s_wipT = -1.f; s_deerWipeIn = -1.f; return; }
    bool wet = g_scene.rain > 0.1f || g_scene.snow > 0.3f;
    if (s_deerWipeIn > 0.f) { s_deerWipeIn -= dt; if (s_deerWipeIn <= 0.f && s_wipT < 0.f) { s_wipT = 0.f; s_wipLen = 1.7f; s_wipDeer = true; s_wipEvent = true; s_wipEventDeer = true; } }
    if (s_wipT < 0.f && wet) {
        s_wipPause -= dt;
        if (s_wipPause <= 0.f) { s_wipT = 0.f; s_wipLen = 1.05f; s_wipDeer = false; s_wipEvent = true; s_wipEventDeer = false; }
    }
    float prev = s_wipAng;
    if (s_wipT >= 0.f) {
        s_wipT += dt;
        if (s_wipT >= s_wipLen) {
            s_wipT = -1.f; s_wipAng = WIPE_REST;
            float r = g_scene.rain + g_scene.snow * 0.5f;
            s_wipPause = r > 0.5f ? 0.05f : (r > 0.25f ? 1.2f : 3.5f);   // heavy: continuous; light: intermittent
        } else s_wipAng = wiperAngle(s_wipT, s_wipLen);
    } else s_wipAng = WIPE_REST;
    const int pv[2] = {(int)(W * 0.30f), (int)(W * 0.68f)};
    const float L = W * 0.40f;
    float a0 = fminf(prev, s_wipAng), a1 = fmaxf(prev, s_wipAng);
    for (int w = 0; w < 2; w++) {
        float px = (float)pv[w], py = (float)s_bottomCock[pv[w]] - 1.f;
        // the glass it passes over is clean again
        for (Splat& sp : s_spl) {
            if (sp.life <= 0.f) continue;
            float dx = sp.x - px, dy = py - sp.y;
            float r = sqrtf(dx * dx + dy * dy), a = atan2f(dy, dx);
            if (r < L + 2.f && a >= a0 - 0.05f && a <= a1 + 0.05f) sp.life = 0.f;
        }
        // arm and blade (parked out of sight below the glass when they're not sweeping)
        if (s_wipT < 0.f) continue;
        float ca = cosf(s_wipAng), sa = sinf(s_wipAng);
        for (float t = 0.f; t < L; t += 0.7f) {
            int x = (int)(px + ca * t), y = (int)(py - sa * t);
            if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) continue;
            fb[y * W + x] = P_BLACK;
            if (t > L * 0.3f) { int x2 = (int)(px + ca * t - sa), y2 = (int)(py - sa * t - ca); if ((unsigned)x2 < (unsigned)W && (unsigned)y2 < (unsigned)H) fb[y2 * W + x2] = P_BLACK; }
        }
    }
}

static void drawGlass() {
    float dt = g_scene.dt;
    if (g_view.view == VIEW_COCKPIT && g_scene.rain > 0.1f && hashf((uint32_t)(s_t * 60.f)) < g_scene.rain * 0.6f) renderWater(0.3f);
    for (Splat& s : s_spl) {
        if (s.life <= 0.f) continue;
        s.life -= dt;
        if (s.kind == 1) s.y += dt * (6.f + g_view.speedMph * 0.3f);
        int R = (int)s.r;
        for (int dy = -R; dy <= R; dy++) for (int dx = -R; dx <= R; dx++) {
            if (dx * dx + dy * dy > R * R) continue;
            int x = (int)s.x + dx, y = (int)s.y + dy;
            if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) continue;
            if (s.kind == 0) { if (s.life > 1.f || dith(x, y) < s.life) fb[y * W + x] = (dx * dx + dy * dy < R * R / 3) ? P_MUD : (((x ^ y) & 1) ? P_MUD : fb[y * W + x]); }
            else if (s.kind == 2) { if ((dx + dy) & 1 || R < 2) fb[y * W + x] = (uint8_t)(P_FLOWER + 3 + ((x * 7 + y) & 1)); }
            else fb[y * W + x] = s_bright[fb[y * W + x]];
        }
    }
}

// ---- instruments: as little as possible, out of the way
static void hudText(int x, int y, const char* s, uint8_t c, int sc = 1) { font3(fb, W, H, x, y, s, c, P_HUD_K, sc); }
static void drawHud() {
    const ViewInfo& v = g_view;
    char t[24];
    // speed: on the dash in the cockpit, a corner readout otherwise
    snprintf(t, sizeof t, "%d", (int)(v.speedMph + 0.5f));
    if (v.view == VIEW_COCKPIT) {
        static const int8_t SP[4][2] = {{82, 99}, {112, 101}, {113, 100}, {80, 111}};
        int w = font3Width(t);
        hudText(SP[v.vehicle][0] - w / 2, SP[v.vehicle][1], t, P_HUD_G);
    } else {
        int w = font3Width(t, 2);
        hudText(W - 4 - w, H - 13, t, P_HUD_W, 2);
        hudText(W - 4 - 11, H - 20, "MPH", P_HUD_W);
    }
    if (v.reverse) hudText(W - 8, 3, "R", P_HUD_A);
    // the pace note (the STI's co-driver)
    if (v.paceA > 0.1f) {
        char p[8];
        if (v.paceDir == 0) hudText(4, 4, "CREST", P_HUD_A);             // crests: the small call
        else {
            snprintf(p, sizeof p, "%s%s%d", v.paceDir < 0 ? "<" : "", v.paceSev == 1 ? "H" : "", v.paceSev);
            if (v.paceDir > 0) { size_t n = strlen(p); p[n] = '>'; p[n + 1] = 0; }
            hudText(4, 4, p, v.paceSev <= 2 ? P_HUD_R : P_HUD_A, 2);
        }
        if (v.paceCrest && v.paceDir != 0) hudText(4, 16, "CREST", P_HUD_A);
    }
    // a fork ahead: where each side goes
    if (v.juncA > 0.05f && v.juncL && v.juncR) {
        hudText(4, H - 22 - (v.view == VIEW_COCKPIT ? 26 : 0) + 30 - 30 + 0, "", P_HUD_W);
        int y = v.view == VIEW_COCKPIT ? 4 : 4;
        int wl = font3Width(v.juncL), wr = font3Width(v.juncR);
        hudText(W / 2 - wl - 6, y + (v.paceA > 0.1f ? 0 : 0), v.juncL, P_HUD_W);
        hudText(W / 2 + 6, y, v.juncR, P_HUD_W);
        (void)wr;
    }
    if (v.storeA > 0.05f) hudText(W / 2 - font3Width("$ MANTIS MOTORS") / 2, 12, "$ MANTIS MOTORS", P_HUD_A);
    if (v.offroadLeft >= 0.f) {
        snprintf(t, sizeof t, "%d", (int)ceilf(v.offroadLeft));
        hudText(W / 2 - font3Width(t, 3) / 2, 30, t, P_HUD_R, 3);
        hudText(W / 2 - font3Width("BACK TO THE ROAD") / 2, 48, "BACK TO THE ROAD", P_HUD_R);
    }
    if (v.msg && v.msgA > 0.05f) {
        hudText(W / 2 - font3Width(v.msg) / 2, 22, v.msg, P_HUD_W);
        if (v.sub) hudText(W / 2 - font3Width(v.sub) / 2, 30, v.sub, P_HUD_A);
    }
    if (v.showFps) { snprintf(t, sizeof t, "%d", v.fps); hudText(2, H - 8, t, P_HUD_G); if (g_memNote) hudText(2, H - 15, g_memNote, g_memNote[4] == 'O' ? P_HUD_G : P_HUD_R); }
}

// ================================================================================== frame
void renderSetVehicle(uint8_t veh) {
    s_veh = veh % V_COUNT;
    const art::CockArt& c = art::COCK_ART[s_veh];
    if (!s_cock) { s_cock = (uint8_t*)memSlow(W * H); s_wheelMask = (uint8_t*)memSlow(W * H); }
    if (!s_cock || !s_wheelMask) return;
    for (int i = 0; i < W * H; i++) s_cock[i] = (i & 1) ? (c.px[i >> 1] & 15) : (c.px[i >> 1] >> 4);
    memset(s_wheelMask, 0, W * H);
    // the glass's lowest row per column: wheel pixels above it have the world behind them, below it the dash
    for (int x = 0; x < W; x++) {
        int g = -1;
        for (int y = 0; y < H; y++) if (!s_cock[y * W + x]) g = y;
        s_glassLow[x] = (uint8_t)(g < 0 ? 0 : g);
    }
    if (c.wr > 0) {
        // the wheel by its shape: the rim (a ring at its radius), the hub, and the three spokes (left, right, down at
        // rest, as all the cockpit drawings have them). The dash and gauges seen through it stay where they are.
        auto lumAt = [&](int x, int y) -> float {
            uint8_t p = s_cock[y * W + x]; if (!p) return 999.f;
            const uint8_t* rgb = c.pal + (p - 1) * 3; return rgb[0] * 0.3f + rgb[1] * 0.59f + rgb[2] * 0.11f; };
        // its ellipse: the rim's left / right ends on the centre row against its top on the centre column
        int xl = c.wx, xr = c.wx, yt = c.wy;
        for (int x = c.wx - c.wr - 3; x <= c.wx; x++) if (x >= 0 && lumAt(x, c.wy) < 80.f) { xl = x; break; }
        for (int x = c.wx + c.wr + 3; x >= c.wx; x--) if (x < W && lumAt(x, c.wy) < 80.f) { xr = x; break; }
        for (int y = c.wy - c.wr - 3; y <= c.wy; y++) if (y >= 0 && lumAt(c.wx, y) < 80.f) { yt = y; break; }
        float rx = (xr - xl) * 0.5f, ry = (float)(c.wy - yt);
        s_wcx = (float)c.wx; s_wcy = (float)c.wy;
        const WheelFit& fit = WHEEL_FIT[s_veh];
        const bool fitted = fit.rx > 0.f;
        if (fitted) { s_wcx = fit.cx; s_wcy = fit.cy; rx = fit.rx; ry = fit.ry; }
        s_wheelK = (rx > 4.f && ry > 4.f) ? clampf(rx / ry, 0.8f, 2.f) : 1.f;
        float R = rx > 4.f ? rx : (float)c.wr;
        int cnt[16] = {0};
        for (int y = c.wy - c.wr - 4; y <= c.wy + c.wr + 8; y++) for (int x = c.wx - c.wr - 4; x <= c.wx + c.wr + 4; x++) {
            if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H || !s_cock[y * W + x]) continue;
            float dx = (float)x - s_wcx, dy = ((float)y - s_wcy) * s_wheelK;
            float d = sqrtf(dx * dx + dy * dy) / R;
            bool rim, hub, spoke;
            if (fitted) {                                                 // the whole drawn wheel: rim and its outline, spokes, hub
                rim = d > 0.76f && d < 1.10f;
                float hx = (float)x - fit.hubX, hy = (float)y - fit.hubY;
                hub = hx * hx + hy * hy <= fit.hubR * fit.hubR;
                spoke = d <= 0.80f && ((fabsf((float)y - fit.spokeY) <= fit.spokeH) || ((float)y > fit.hubY && fabsf(hx) <= fit.spokeH));
            } else {
                rim = d > 0.80f && d < 1.12f && lumAt(x, y) < 90.f;     // the rim is the dark ring, not whatever is beside it
                hub = d < 0.30f;
                spoke = d >= 0.30f && d <= 0.85f && ((fabsf(dy) < 2.2f) || (dy > 0.f && fabsf(dx) < 2.2f));
            }
            if (rim || hub || spoke) s_wheelMask[y * W + x] = 1;
            else if (d > 1.15f && d < 1.5f && y > s_glassLow[x]) cnt[s_cock[y * W + x]]++;   // the dash around the wheel
        }
        int bg = 1;
        for (int k = 1; k < 16; k++) if (cnt[k] > cnt[bg]) bg = k;
        s_wheelBg = (uint8_t)(P_COCK + bg);
        s_wheelR = (int)ceilf(R * 1.15f * fmaxf(1.f, s_wheelK)) + 2;
    }
    // the overlay as runs in internal RAM (drawn every cockpit frame: no PSRAM reads)
    if (!s_ckRun) { s_ckRun = (uint16_t*)memSlow(2400 * 2 * sizeof(uint16_t)); s_ckPix = (uint8_t*)memSlow(W * H / 2); }   // read straight through: PSRAM streams it
    s_ckRuns = 0;
    if (s_ckRun && s_ckPix) {
        int np = 0;
        for (int y = 0; y < H; y++) {
            int x = 0;
            while (x < W) {
                int i = y * W + x;
                if (!s_cock[i] || s_wheelMask[i]) { x++; continue; }
                int st = i, len = 0;
                while (x < W && s_cock[y * W + x] && !s_wheelMask[y * W + x] && np < W * H / 2) { s_ckPix[np++] = (uint8_t)(P_COCK + s_cock[y * W + x]); x++; len++; }
                if (s_ckRuns < 2400) { s_ckRun[s_ckRuns * 2] = (uint16_t)st; s_ckRun[s_ckRuns * 2 + 1] = (uint16_t)len; s_ckRuns++; }
                if (np >= W * H / 2) break;
            }
        }
    }
    // rows the dash covers solidly need no raycast
    for (int x = 0; x < W; x++) {
        int y = H;
        while (y > 0 && s_cock[(y - 1) * W + x]) y--;
        // ...but where the wheel stands in front of the glass, the world is drawn behind it
        if (y > s_glassLow[x] + 1) y = s_glassLow[x] + 1;
        s_bottomCock[x] = (uint8_t)y;
    }
}

void renderInit() {
    if (!zb) zb = (uint8_t*)memFast(W * H);
#ifndef HOST
    if (!s_tWorker) {   // the terrain's second core: priority 3, below the sound (4), the speaker driver (5) and the screen
        // (6): the sound takes core 0 the moment it has work, the terrain only what is left. (At the sound's own priority
        // the two shared the core a tick at a time and the sound fell behind every frame: choppy audio.)
        s_tDone = xSemaphoreCreateBinary();
        if (!s_tDone || xTaskCreatePinnedToCore(terrainWorker, "terrain", 3072, nullptr, 3, &s_tWorker, 0) != pdPASS) s_tWorker = nullptr;
    }
#endif
    if (!s_gpat) s_gpat = (uint8_t*)memSlow(W * H);
    for (int i = 0; i < 32 * 32; i++) s_cloudMap[i] = (uint8_t)(hash32(0xC10D5u + (uint32_t)i * 0x9E3779B1u) >> 24);
    if (!s_tex) {
        s_tex = (uint8_t*)memFast(64 * 64);
        for (int v = 0; v < 64; v++) for (int u = 0; u < 64; u++) {
            float n = fbmP((float)u / 8.f, (float)v / 8.f, 8, 3, 0x7E57u);
            s_tex[v * 64 + u] = (uint8_t)clampi((int)(n * 255.f), 0, 255);
        }
    }
    spritesInit();
    buildLUTs();
    for (int k = 0; k < 80; k++) { float ty = clampf(k / 78.f, 0.f, 1.f); s_skyPow[k] = 9.f * powf(ty, 1.2f); s_skyTT[k] = ty * ty; }
    renderSetVehicle(0);
    memset(fb, 0, sizeof(fb));
}

void renderFrame() {
    s_mistOn = (S.mist * 0.4f + g_scene.mist + g_scene.fog * 0.35f) >= 0.04f;
    if (!s_rankMade && s_tex) makeTexRank();
    const Scene& sc = g_scene;
    s_t = sc.t;
    if (g_view.vehicle != s_veh) renderSetVehicle(g_view.vehicle);
    buildPalette();
    setupCamera();
    // sunlight per baked normal, and fog by distance, once a frame
    float se = fmaxf(sc.sunElev, 0.f);
    s_sunDx = cosf(sc.sunAz) * cosf(se); s_sunDz = sinf(sc.sunAz) * cosf(se); s_sunDy = sinf(se) + 0.15f;
    for (int b = 0; b < 256; b++) {
        float nx = ((b >> 4) - 8) / 8.f, nz = ((b & 15) - 8) / 8.f;
        float ny = sqrtf(fmaxf(0.05f, 1.f - nx * nx - nz * nz));
        float d = fmaxf(0.f, nx * s_sunDx + ny * s_sunDy + nz * s_sunDz);
        s_light[b] = 0.22f + 0.1f * ny + 0.62f * d * s_sunK;
        s_lightSh[b] = 0.22f + 0.1f * ny;
    }
    {   // the ground's grain lit from the sun's side, and the props' shadows on the ground (sunny days only)
        const float hx = cosf(sc.sunAz), hz = sinf(sc.sunAz);
        s_rdu = hx > 0.38f ? 1 : (hx < -0.38f ? -1 : 0);
        s_rdv = hz > 0.38f ? 1 : (hz < -0.38f ? -1 : 0);
        s_reliefK = s_sunK * (1.f / 45.f);
        // cloud shadows: more cover, more of the map in shade; none under a clear sky or a full overcast
        const float cover = g_scene.cloud;
        s_cloudAmt = s_sunK > 0.2f ? 0.16f * clampf(cover * 3.f, 0.f, 1.f) * clampf((0.9f - cover) * 4.f, 0.f, 1.f) : 0.f;
        s_cloudThr = 255.f * (1.f - cover * 0.8f) - 20.f;
        const float drift = (2.f + g_scene.wind * 6.f) * g_scene.dt;      // the shadows move with the wind
        s_cloudOx -= cosf(g_scene.windAz) * drift; s_cloudOz -= sinf(g_scene.windAz) * drift;
        if (fabsf(s_cloudOx) > 2240.f * 64.f) s_cloudOx = fmodf(s_cloudOx, 2240.f);   // (the map repeats every 2240 m)
        if (fabsf(s_cloudOz) > 2240.f * 64.f) s_cloudOz = fmodf(s_cloudOz, 2240.f);
        s_propSh = s_sunK > 0.25f;
        const float rel = wrapPi(sc.sunAz - cyaw), low = clampf(1.f - sc.sunElev / 0.6f, 0.f, 1.f);
        s_propShX = -sinf(rel) * (0.5f + 0.9f * low);       // away from the sun: left when it's to the right
        s_propShY = -cosf(rel) * 0.6f;                      // toward you when it's ahead (lower on screen)
    }
    float vis = 330.f - sc.fog * 250.f - sc.rain * 90.f - sc.snow * 120.f - sc.dust * 80.f;
    vis = fmaxf(vis, 40.f);
    for (int z = 0; z < 520; z++) s_fog[z] = clampf((z - vis * 0.42f) / (vis * 1.0f), 0.f, 1.f);
    const Land& L = journeyLand();
    s_flowers = L.flowers; s_wet = sc.wet; s_paved = L.paved;
    if (g_view.vehicle != s_veh) renderSetVehicle(g_view.vehicle);
    if (g_view.view != VIEW_COCKPIT || g_view.photo) memset(s_bottom, H, sizeof(s_bottom));   // photo mode: out of the car, the whole picture
    else memcpy(s_bottom, s_bottomCock, sizeof(s_bottom));
    memset(zb, 255, W * H);
    drawTerrain(560.f);
    drawSkyAndPanorama();
    drawNight();
    drawSun();
    drawClouds();
    drawBolt();
    drawBirds();
    drawRoadStructures();
    drawVegetation();
    drawFarm();
    drawArches();
    drawGeysers();
    drawRamps();
    drawSignAndStore();
    drawCritters();
    drawParticles();
    reflectPass();
    drawGlint();
    drawFireflies();
    drawMist();
    drawShafts();
    drawRain();
    drawSnow();
    drawLeaves();
    if (g_view.photo) { s_frameN++; return; }        // the viewfinder: the world only
    if (g_view.view == VIEW_CHASE) drawChaseVehicle();
    drawWipers();                                   // before the dash, which hides their pivots
    if (g_view.view == VIEW_COCKPIT) drawCockpit();
    drawGlass();
    drawHud();
    s_bob = 0.f;
    s_frameN++;
}

// ---- photo mode: the hero art, set into the scene ----
static int s_phX0 = 0, s_phY0 = 0, s_phX1 = -1, s_phY1 = -1;      // what the overlay holds now
void renderPhotoClear() {
    uint16_t* o = overlayBuffer();
    if (o && s_phX1 >= s_phX0) for (int y = s_phY0; y <= s_phY1; y++) memset(o + y * 320 + s_phX0, 0, (size_t)(s_phX1 - s_phX0 + 1) * 2);
    s_phX1 = -1;
    overlayEnable(false);
}
bool renderPhotoCompose(const PhotoArt& a) {
    uint16_t* o = overlayBuffer();
    if (!o || !a.px) return false;
    renderPhotoClear();
    float sx, sy, d;
    if (!renderProject(a.x, a.y, a.z, sx, sy, d)) return false;
    uint8_t zc = zcode(d);
    // its shadow on the ground (the world, darkened)
    int scx = (int)sx, scy = (int)sy, srx = (int)(a.shadowW * 0.5f * F / d), sry = srx / 5 + 1;
    for (int y = -sry; y <= sry; y++) for (int x = -srx; x <= srx; x++) {
        if ((x * x) * sry * sry + (y * y) * srx * srx > srx * srx * sry * sry) continue;
        int X = scx + x, Y = scy + y;
        if ((unsigned)X < (unsigned)W && (unsigned)Y < (unsigned)H && zb[Y * W + X] + 1 >= zc) fb[Y * W + X] = s_refl[s_refl[fb[Y * W + X]]];
    }
    // the art: its foot on the ground point, at full resolution, lit, behind anything nearer
    int ox = (int)lroundf(sx * 2.f) - a.w / 2, oy = (int)lroundf(sy * 2.f) - a.h;
    float lr = s_artLit[0], lg = s_artLit[1], lb = s_artLit[2];
    bool any = false;
    for (int y = 0; y < a.h; y++) {
        int Y = oy + y;
        if ((unsigned)Y >= 240u) continue;
        for (int x = 0; x < a.w; x++) {
            int X = ox + x;
            if ((unsigned)X >= 320u) continue;
            uint16_t p = a.px[y * a.w + (a.mirror ? a.w - 1 - x : x)];
            if (!p) continue;
            if (zb[(Y >> 1) * W + (X >> 1)] + 2 < zc) continue;            // grass, a tree, a rock in front of it
            int R = (int)(((p >> 11) & 31) * lr), G = (int)(((p >> 5) & 63) * lg), B = (int)((p & 31) * lb);
            uint16_t q = (uint16_t)((clampi(R, 0, 31) << 11) | (clampi(G, 0, 63) << 5) | clampi(B, 0, 31));
            o[Y * 320 + X] = q ? q : 0x0821;
            any = true;
        }
    }
    s_phX0 = clampi(ox, 0, 319); s_phX1 = clampi(ox + a.w - 1, 0, 319); s_phY0 = clampi(oy, 0, 239); s_phY1 = clampi(oy + a.h - 1, 0, 239);
    overlayEnable(true);
    return any;
}

const uint8_t* frameBuffer() { return fb; }
bool renderDepthFast() { return memIsFast(zb); }
const char* g_memNote = nullptr;
const uint16_t* framePalette565() { return pal565q; }
const uint8_t* framePaletteRGB() { return palRGB; }
int frameBob() { return 0; }

}
